package com.tsconv.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

@androidx.annotation.OptIn(UnstableApi::class)
class PlayerActivity : Activity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var msg: TextView
    private var url = ""
    private var triedAlt = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        url = intent.getStringExtra("url") ?: run { finish(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply {
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            useController = true
        }
        msg = TextView(this).apply {
            setTextColor(Color.parseColor("#F2EEE3"))
            textSize = 15f
            gravity = Gravity.CENTER
            visibility = View.GONE
            setPadding(48, 48, 48, 48)
            setOnClickListener { visibility = View.GONE; startPlayer() }
        }
        frame.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        frame.addView(msg, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setContentView(frame)
    }

    override fun onStart() {
        super.onStart()
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        startPlayer()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    private fun startPlayer() {
        releasePlayer()
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("VLC/3.0.20 LibVLC/3.0.20")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()

        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                var c: Throwable? = error
                var code: Int? = null
                while (c != null) {
                    if (c is HttpDataSource.InvalidResponseCodeException) { code = c.responseCode; break }
                    c = c.cause
                }
                // جرّب الصيغة الثانية مرة واحدة (.m3u8 <-> .ts)
                if (code != null && !triedAlt) {
                    val base = url.substringBefore('?')
                    val tail = url.removePrefix(base)
                    val alt = when {
                        base.endsWith(".m3u8", true) -> base.dropLast(5) + ".ts"
                        base.endsWith(".ts", true) -> base.dropLast(3) + ".m3u8"
                        else -> null
                    }
                    if (alt != null) { triedAlt = true; url = alt + tail; startPlayer(); return }
                }
                val hint = when (code) {
                    401, 403 -> "الاشتراك منتهٍ أو البيانات خاطئة أو الحساب محظور/مربوط بجهاز آخر"
                    404 -> "القناة أو الصيغة غير موجودة على السيرفر"
                    429, 458, 884 -> "تجاوزت عدد الاتصالات المسموح، أو السيرفر رفض الطلب"
                    in 500..599 -> "السيرفر نفسه معطّل أو مشغول"
                    else -> ""
                }
                msg.text = "تعذر تشغيل البث\n" +
                    (if (code != null) "رمز السيرفر: $code" else error.errorCodeName) +
                    (if (hint.isNotEmpty()) "\n$hint" else "") +
                    "\n\nاضغط لإعادة المحاولة"
                msg.visibility = View.VISIBLE
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) msg.visibility = View.GONE
            }
        })

        val item = MediaItem.Builder().setUri(url).apply {
            if (url.substringBefore('?').endsWith(".m3u8", true)) setMimeType(MimeTypes.APPLICATION_M3U8)
        }.build()

        p.setMediaItem(item)
        p.prepare()
        p.playWhenReady = true
        playerView.player = p
        player = p
    }

    private fun releasePlayer() {
        playerView.player = null
        player?.release()
        player = null
    }
}
