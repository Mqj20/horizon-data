package com.tsconv.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/** قائمة حسابات الاكستريم المحفوظة (حتى مئات الحسابات): تصفح، بحث، إضافة، فحص، ودخول لأي حساب. */
class AccountsActivity : Activity() {

    private lateinit var filter: EditText
    private lateinit var status: TextView
    private lateinit var list: ListView

    private var all: MutableList<AccountStore.Acc> = ArrayList()
    private val shown = ArrayList<AccountStore.Acc>()
    private var checking = false

    private val dialogTheme = android.R.style.Theme_DeviceDefault_Dialog_Alert
    private val okColor = Color.parseColor("#4CAF50")
    private val badColor = Color.parseColor("#E5534B")

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.bg
        window.navigationBarColor = Ui.bg
        AccountStore.migrateOld(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.bg)
            setPadding(dp(18), dp(30), dp(18), dp(14))
        }
        root.addView(Ui.label(this, "📡  حسابات الاكستريم", 22f, Ui.gold), Ui.lp(this, 12))

        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(Ui.button(this, "➕ إضافة حساب", true) { addDialog() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
        r1.addView(Ui.button(this, "📋 لصق عدة حسابات", false) { bulkDialog() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(r1, Ui.lp(this, 8))

        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(Ui.button(this, "🔄 فحص الكل", false) { checkAll() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
        r2.addView(Ui.button(this, "🗑 حذف الكل", false) { deleteAllDialog() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(r2, Ui.lp(this, 8))

        status = Ui.label(this, "", 12f, Ui.textDim).apply { gravity = Gravity.CENTER }
        root.addView(status, Ui.lp(this, 8))

        filter = Ui.field(this, "🔍  بحث في الحسابات (اسم، سيرفر، مستخدم)")
        filter.inputType = InputType.TYPE_CLASS_TEXT
        filter.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { applyFilter() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        root.addView(filter, Ui.lp(this, 8))

        list = ListView(this).apply {
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(8)
            adapter = Adapter()
            setOnItemClickListener { _, _, pos, _ -> openAccount(shown[pos]) }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (!checking) reload()
    }

    override fun onPause() {
        super.onPause()
        if (all.isNotEmpty() && !checking) AccountStore.save(this, all)
    }

    private fun reload() {
        all = AccountStore.load(this)
        applyFilter()
    }

    private fun applyFilter() {
        val q = filter.text.toString().trim().lowercase()
        shown.clear()
        shown.addAll(
            if (q.isEmpty()) all
            else all.filter { (it.name + " " + it.base + " " + it.user).lowercase().contains(q) }
        )
        (list.adapter as BaseAdapter).notifyDataSetChanged()
        val good = all.count { it.ok == 1 }
        val bad = all.count { it.ok == -1 }
        status.text = if (all.isEmpty()) "ما عندك حسابات محفوظة. أضف حساب أو الصق عدة حسابات."
        else "${all.size} حساب" + (if (good + bad > 0) "  •  ✅ $good  ❌ $bad" else "") +
            (if (q.isNotEmpty()) "  •  المعروض ${shown.size}" else "")
    }

    private fun persist() {
        AccountStore.save(this, all)
    }

    // ───────────── الدخول لحساب ─────────────
    private fun openAccount(a: AccountStore.Acc) {
        persist()
        startActivity(
            Intent(this, XtreamActivity::class.java)
                .putExtra("acct_base", a.base).putExtra("acct_user", a.user).putExtra("acct_pass", a.pass)
        )
    }

    // ───────────── إضافة ─────────────
    private fun addDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val n = Ui.field(this, "اسم للحساب (اختياري)").apply { inputType = InputType.TYPE_CLASS_TEXT }
        val s = Ui.field(this, "السيرفر  http://host:port  أو رابط get.php كامل")
        val u = Ui.field(this, "اسم المستخدم")
        val p = Ui.field(this, "كلمة المرور", password = true)
        listOf(n, s, u, p).forEach { box.addView(it, Ui.lp(this, 8)) }
        AlertDialog.Builder(this, dialogTheme)
            .setTitle("إضافة حساب")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val parsed = XtreamApi.parseServer(s.text.toString())
                if (parsed == null) {
                    Toast.makeText(this, "اكتب عنوان السيرفر", Toast.LENGTH_SHORT).show(); return@setPositiveButton
                }
                val user = u.text.toString().trim().ifEmpty { parsed.user }
                val pass = p.text.toString().trim().ifEmpty { parsed.pass }
                if (user.isEmpty() || pass.isEmpty()) {
                    Toast.makeText(this, "اكتب اسم المستخدم وكلمة المرور", Toast.LENGTH_SHORT).show(); return@setPositiveButton
                }
                val isNew = AccountStore.upsert(this, XtreamApi.Creds(parsed.base, user, pass), "", n.text.toString().trim())
                reload()
                Toast.makeText(this, if (isNew) "تم حفظ الحساب" else "الحساب موجود، تم تحديثه", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun bulkDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        box.addView(Ui.label(this, "كل سطر حساب: رابط get.php كامل، أو  سيرفر يوزر باسورد  (بمسافة أو | أو ,)", 12f, Ui.textDim), Ui.lp(this, 8))
        val t = Ui.field(this, "http://host:port/get.php?username=..&password=..").apply {
            setSingleLine(false)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_VARIATION_URI
            minLines = 6
            maxLines = 10
            gravity = Gravity.TOP or Gravity.START
        }
        box.addView(t, Ui.lp(this, 0))
        AlertDialog.Builder(this, dialogTheme)
            .setTitle("لصق عدة حسابات")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val (added, dup, bad) = AccountStore.addBulk(this, t.text.toString())
                reload()
                Toast.makeText(this, "أُضيف $added  •  مكرر $dup  •  غير مفهوم $bad", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ───────────── قائمة ⋮ لكل حساب ─────────────
    private fun showMenu(anchor: View, a: AccountStore.Acc) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "فتح الحساب")
        m.menu.add(0, 2, 1, "فحص الحالة")
        m.menu.add(0, 3, 2, "تغيير الاسم")
        m.menu.add(0, 4, 3, "نسخ رابط get.php")
        m.menu.add(0, 5, 4, "حذف")
        m.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> openAccount(a)
                2 -> checkOne(a)
                3 -> renameDialog(a)
                4 -> {
                    Ui.copy(this, "${a.base}/get.php?username=${a.user}&password=${a.pass}&type=m3u_plus&output=ts")
                    Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show()
                }
                5 -> deleteDialog(a)
            }
            true
        }
        m.show()
    }

    private fun renameDialog(a: AccountStore.Acc) {
        val e = Ui.field(this, "الاسم").apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setText(a.name)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(e, Ui.lp(this@AccountsActivity))
        }
        AlertDialog.Builder(this, dialogTheme)
            .setTitle("تغيير الاسم")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val i = all.indexOfFirst { it.id == a.id }
                if (i >= 0) {
                    all[i] = all[i].copy(name = e.text.toString().trim().ifEmpty { AccountStore.defaultName(a.creds()) })
                    persist(); applyFilter()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun deleteDialog(a: AccountStore.Acc) {
        AlertDialog.Builder(this, dialogTheme)
            .setTitle("حذف الحساب؟")
            .setMessage(a.name)
            .setPositiveButton("حذف") { _, _ ->
                all.removeAll { it.id == a.id }
                persist(); applyFilter()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun deleteAllDialog() {
        if (all.isEmpty()) return
        AlertDialog.Builder(this, dialogTheme)
            .setTitle("حذف كل الحسابات؟")
            .setMessage("راح تنحذف ${all.size} حساب من الجهاز.")
            .setPositiveButton("حذف الكل") { _, _ ->
                all.clear()
                persist(); applyFilter()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ───────────── فحص الحالة ─────────────
    private fun probe(a: AccountStore.Acc): Pair<String, Int> =
        try {
            Pair(XtreamApi.login(a.creds()), 1)
        } catch (e: Exception) {
            Pair("❌ " + (e.message ?: e.javaClass.simpleName), -1)
        }

    private fun checkOne(a: AccountStore.Acc) {
        Toast.makeText(this, "جارٍ الفحص...", Toast.LENGTH_SHORT).show()
        Thread {
            val (info, ok) = probe(a)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                val i = all.indexOfFirst { it.id == a.id }
                if (i >= 0) {
                    all[i] = all[i].copy(info = info, ok = ok)
                    persist(); applyFilter()
                }
            }
        }.start()
    }

    /** يفحص كل الحسابات بالتوازي (6 بنفس الوقت) ويعرض التقدم. */
    private fun checkAll() {
        if (checking || all.isEmpty()) return
        checking = true
        val targets = ArrayList(all)
        var done = 0
        val pool = Executors.newFixedThreadPool(6)
        status.text = "جارٍ الفحص 0/${targets.size}"
        targets.forEach { a ->
            pool.execute {
                val (info, ok) = probe(a)
                runOnUiThread {
                    if (isDestroyed) return@runOnUiThread
                    val i = all.indexOfFirst { it.id == a.id }
                    if (i >= 0) all[i] = all[i].copy(info = info, ok = ok)
                    done++
                    if (done >= targets.size) {
                        checking = false
                        persist(); applyFilter()
                    } else {
                        status.text = "جارٍ الفحص $done/${targets.size}"
                        if (done % 10 == 0) (list.adapter as BaseAdapter).notifyDataSetChanged()
                    }
                }
            }
        }
        pool.shutdown()
    }

    // ───────────── الصفوف ─────────────
    private inner class Adapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val a = shown[position]
            val ctx = this@AccountsActivity
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = Ui.ripple(Ui.round(ctx, Ui.card, 14, Ui.stroke))
                setPadding(dp(16), dp(8), dp(4), dp(8))
                minimumHeight = dp(64)
            }
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(ctx).apply {
                text = a.name
                textSize = 15f
                setTextColor(Ui.textMain)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                maxLines = 1
            })
            col.addView(TextView(ctx).apply {
                text = "${a.base.removePrefix("http://").removePrefix("https://")}  •  ${a.user}"
                textSize = 11f
                setTextColor(Ui.textDim)
                maxLines = 1
                textDirection = View.TEXT_DIRECTION_LTR
                gravity = Gravity.START
            })
            if (a.info.isNotEmpty()) {
                col.addView(TextView(ctx).apply {
                    text = (if (a.ok == 1) "✅ " else "") + a.info
                    textSize = 11f
                    setTextColor(if (a.ok == -1) badColor else okColor)
                    maxLines = 1
                })
            }
            row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(ctx).apply {
                text = "⋮"
                textSize = 24f
                setTextColor(Ui.gold)
                gravity = Gravity.CENTER
                setOnClickListener { showMenu(this, a) }
            }, LinearLayout.LayoutParams(dp(52), dp(54)))
            return row
        }
    }
}
