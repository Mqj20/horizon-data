package com.tsconv.app

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** تخزين حسابات الاكستريم المحفوظة على الجهاز (يتحمل مئات الحسابات). */
object AccountStore {

    data class Acc(
        val id: String,
        val name: String,
        val base: String,
        val user: String,
        val pass: String,
        val info: String = "",   // آخر حالة معروفة (تاريخ الانتهاء أو سبب الفشل)
        val ok: Int = 0          // 1 شغال، -1 ما يشتغل، 0 لم يُفحص
    ) {
        fun creds() = XtreamApi.Creds(base, user, pass)
    }

    private const val KEY = "accounts_v1"
    private const val MIGRATED = "accounts_migrated"

    private fun sp(ctx: Context) = Ui.prefs(ctx)

    fun load(ctx: Context): MutableList<Acc> {
        val out = ArrayList<Acc>()
        val txt = sp(ctx).getString(KEY, null) ?: return out
        try {
            val arr = JSONArray(txt)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(
                    Acc(
                        o.optString("id").ifEmpty { UUID.randomUUID().toString() },
                        o.optString("name"), o.optString("base"),
                        o.optString("user"), o.optString("pass"),
                        o.optString("info"), o.optInt("ok", 0)
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun save(ctx: Context, list: List<Acc>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("base", it.base)
                    .put("user", it.user).put("pass", it.pass).put("info", it.info).put("ok", it.ok)
            )
        }
        sp(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    /** الاسم الافتراضي: السيرفر • المستخدم */
    fun defaultName(c: XtreamApi.Creds): String {
        val host = Uri.parse(c.base).host ?: c.base
        return "$host • ${c.user}"
    }

    fun exists(list: List<Acc>, c: XtreamApi.Creds) =
        list.indexOfFirst { it.base.equals(c.base, true) && it.user == c.user }

    /** يضيف حساباً جديداً، أو يحدّث الموجود (نفس السيرفر والمستخدم). يرجع true لو كان جديداً. */
    fun upsert(ctx: Context, c: XtreamApi.Creds, info: String, name: String? = null): Boolean {
        val list = load(ctx)
        val i = exists(list, c)
        val isNew = i < 0
        if (isNew) {
            list.add(Acc(UUID.randomUUID().toString(), name?.ifBlank { null } ?: defaultName(c), c.base, c.user, c.pass, info, if (info.isEmpty()) 0 else 1))
        } else {
            val old = list[i]
            list[i] = old.copy(
                pass = c.pass,
                name = name?.ifBlank { null } ?: old.name,
                info = if (info.isEmpty()) old.info else info,
                ok = if (info.isEmpty()) old.ok else 1
            )
        }
        save(ctx, list)
        return isNew
    }

    /**
     * لصق عدة حسابات: كل سطر إما رابط get.php كامل، أو "سيرفر يوزر باسورد" مفصولة بمسافة أو | أو ,
     * يرجع (المضاف، المكرر، غير المفهوم).
     */
    fun addBulk(ctx: Context, text: String): Triple<Int, Int, Int> {
        val list = load(ctx)
        var added = 0
        var dup = 0
        var bad = 0
        text.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#EXTM3U") }.forEach { line ->
            val c = parseLine(line)
            if (c == null) {
                bad++
            } else if (exists(list, c) >= 0) {
                dup++
            } else {
                list.add(Acc(UUID.randomUUID().toString(), defaultName(c), c.base, c.user, c.pass))
                added++
            }
        }
        if (added > 0) save(ctx, list)
        return Triple(added, dup, bad)
    }

    private fun parseLine(line: String): XtreamApi.Creds? {
        val parts = line.split(Regex("[\\s|,;]+")).filter { it.isNotEmpty() }
        if (parts.size >= 3 && !line.contains("username=")) {
            val p = XtreamApi.parseServer(parts[0]) ?: return null
            return XtreamApi.Creds(p.base, parts[1], parts[2])
        }
        val p = XtreamApi.parseServer(parts.firstOrNull() ?: return null) ?: return null
        return if (p.user.isNotEmpty() && p.pass.isNotEmpty()) p else null
    }

    /** نقل الحساب الوحيد القديم (من النسخة السابقة) إلى القائمة مرة واحدة. */
    fun migrateOld(ctx: Context) {
        val p = sp(ctx)
        if (p.getBoolean(MIGRATED, false)) return
        p.edit().putBoolean(MIGRATED, true).apply()
        val s = p.getString("server", "") ?: ""
        val u = p.getString("user", "") ?: ""
        val pw = p.getString("pass", "") ?: ""
        if (s.isNotBlank() && u.isNotBlank() && pw.isNotBlank()) {
            val c = XtreamApi.parseServer(s)?.let { XtreamApi.Creds(it.base, u, pw) } ?: return
            upsert(ctx, c, "")
        }
    }
}
