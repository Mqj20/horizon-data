package com.tsconv.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

/** رفع ملف من الجهاز (connect.json مثلاً) ← تشفيره كامل (أو فكه) ← حفظه كملف. */
class FileCryptoActivity : Activity() {

    private companion object {
        const val REQ_PICK = 11
        const val REQ_SAVE = 12
        const val MAX_BYTES = 20 * 1024 * 1024
    }

    private lateinit var pass: EditText
    private lateinit var fileInfo: TextView
    private lateinit var status: TextView
    private lateinit var encBtn: Button
    private lateinit var decBtn: Button
    private lateinit var runBtn: Button

    private var encryptMode = true
    private var data: ByteArray? = null
    private var fileName = ""
    private var result: ByteArray? = null
    private var resultName = ""

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.bg
        window.navigationBarColor = Ui.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.bg)
            setPadding(dp(18), dp(30), dp(18), dp(24))
        }
        root.addView(Ui.label(this, "📁  تشفير ملف كامل", 22f, Ui.gold), Ui.lp(this, 12))

        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.round(this@FileCryptoActivity, Ui.card, 30, Ui.stroke)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        encBtn = pill("تشفير") { encryptMode = true; refreshMode() }
        decBtn = pill("فك التشفير") { encryptMode = false; refreshMode() }
        seg.addView(encBtn, LinearLayout.LayoutParams(0, -2, 1f))
        seg.addView(decBtn, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(seg, Ui.lp(this, 12))

        pass = Ui.field(this, "كلمة سر (اختياري - الفاضي = المفتاح المدمج)", password = true)
        pass.setText(Ui.prefs(this).getString("cpass", ""))
        root.addView(pass, Ui.lp(this, 12))

        root.addView(Ui.button(this, "📂   اختيار ملف من الجهاز", false) { pick() }, Ui.lp(this, 8))
        fileInfo = Ui.label(this, "ما اخترت ملف", 13f, Ui.textDim).apply {
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_LTR
        }
        root.addView(fileInfo, Ui.lp(this, 14))

        runBtn = Ui.button(this, "▶   تنفيذ وحفظ الملف", true) { run() }
        root.addView(runBtn, Ui.lp(this, 10))
        status = Ui.label(this, "", 13f, Ui.textDim).apply { gravity = Gravity.CENTER }
        root.addView(status, Ui.lp(this, 10))
        root.addView(Ui.button(this, "💾   حفظ النتيجة مرة ثانية", false) { result?.let { save() } }, Ui.lp(this, 0))

        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.bg); isFillViewport = true; addView(root) })
        refreshMode()
    }

    private fun pill(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 13f; stateListAnimator = null
        setOnClickListener { onClick() }
    }

    private fun refreshMode() {
        fun style(b: Button, on: Boolean) {
            b.setTextColor(if (on) android.graphics.Color.parseColor("#1A1405") else Ui.textDim)
            b.background = if (on) Ui.round(this, Ui.gold, 26) else null
        }
        style(encBtn, encryptMode); style(decBtn, !encryptMode)
        runBtn.text = if (encryptMode) "▶   تشفير وحفظ الملف" else "▶   فك التشفير وحفظ الملف"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun pick() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }, REQ_PICK)
    }

    private fun nameOf(uri: Uri): String = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: "file"
    } catch (e: Exception) { "file" }

    private fun load(uri: Uri) {
        status.text = "جاري القراءة..."
        thread {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                val name = nameOf(uri)
                runOnUiThread {
                    when {
                        bytes == null -> status.text = "تعذر قراءة الملف"
                        bytes.size > MAX_BYTES -> status.text = "الملف كبير (الحد 20 ميجا)"
                        else -> {
                            data = bytes; fileName = name; result = null
                            fileInfo.text = "$name  •  ${bytes.size / 1024 + 1} KB"
                            status.text = ""
                            // اختيار الوضع تلقائياً: ملف مشفّر ← فك، غيره ← تشفير
                            encryptMode = !LinkCrypto.looksEncrypted(bytes)
                            refreshMode()
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "تعذر قراءة الملف" }
            }
        }
    }

    private fun run() {
        val src = data
        if (src == null) { toast("اختر ملف أولاً"); return }
        val p = pass.text.toString()
        Ui.prefs(this).edit().putString("cpass", p).apply()
        val enc = encryptMode
        status.text = "جاري المعالجة..."
        thread {
            try {
                val out = if (enc) LinkCrypto.encryptBytes(src, p) else LinkCrypto.decryptBytes(src, p)
                runOnUiThread {
                    if (out == null) {
                        status.text = "فشل فك التشفير (كلمة السر خاطئة أو الملف غير مشفّر)"
                    } else {
                        result = out
                        resultName = if (enc) "$fileName.enc"
                        else if (fileName.endsWith(".enc", true)) fileName.dropLast(4)
                        else "$fileName.dec"
                        status.text = if (enc) "تم التشفير ✓" else "تم فك التشفير ✓"
                        save()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "فشلت المعالجة" }
            }
        }
    }

    private fun save() {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, resultName)
        }, REQ_SAVE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_PICK -> load(uri)
            REQ_SAVE -> {
                val out = result ?: return
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(out) }
                    toast("تم حفظ الملف")
                } catch (e: Exception) { toast("تعذر حفظ الملف") }
            }
        }
    }
}
