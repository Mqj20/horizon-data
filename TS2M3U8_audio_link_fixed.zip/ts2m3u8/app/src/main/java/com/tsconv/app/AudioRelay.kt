package com.tsconv.app

import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import kotlin.concurrent.thread

class HttpEx(val code: Int) : IOException("HTTP $code")

/** العميل (المشغّل) قطع الاتصال */
class ClientGone : RuntimeException()

private class ClientOut(private val o: OutputStream) : OutputStream() {
    override fun write(b: Int) { try { o.write(b) } catch (e: IOException) { throw ClientGone() } }
    override fun write(b: ByteArray, off: Int, len: Int) { try { o.write(b, off, len) } catch (e: IOException) { throw ClientGone() } }
    override fun flush() { try { o.flush() } catch (e: IOException) { throw ClientGone() } }
}

/** يقرأ بث القناة (TS مباشر أو HLS) ويرسل الصوت فقط. */
object AudioRelay {
    private const val UA = "VLC/3.0.20 LibVLC/3.0.20"

    private fun open(url: String): HttpURLConnection {
        var u = url
        for (i in 0 until 6) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15_000
            c.readTimeout = 20_000
            c.setRequestProperty("User-Agent", UA)
            val code = c.responseCode
            if (code in 301..303 || code == 307 || code == 308) {
                val loc = c.getHeaderField("Location") ?: throw HttpEx(code)
                u = URL(URL(u), loc).toString()
                c.disconnect()
                continue
            }
            if (code !in 200..299) { c.disconnect(); throw HttpEx(code) }
            return c
        }
        throw IOException("redirects")
    }

    private fun alt(url: String): String? {
        val base = url.substringBefore('?')
        val tail = url.removePrefix(base)
        return when {
            base.endsWith(".m3u8", true) -> base.dropLast(5) + ".ts" + tail
            base.endsWith(".ts", true) -> base.dropLast(3) + ".m3u8" + tail
            else -> null
        }
    }

    fun stream(source: String, rawOut: OutputStream) {
        val out = ClientOut(rawOut)
        var u = source
        var tried = false
        while (true) {
            val conn = try { open(u) } catch (e: HttpEx) {
                val a = alt(u)
                if (!tried && a != null) { tried = true; u = a; continue }
                throw e
            }
            conn.inputStream.use { run(u, it, out) }
            return
        }
    }

    private fun run(url: String, raw: InputStream, out: OutputStream) {
        val inp = BufferedInputStream(raw, 64 * 1024)
        inp.mark(16)
        val head = ByteArray(7)
        val n = inp.read(head)
        inp.reset()
        val filter = TsAudioFilter(out)
        if (n == 7 && String(head, Charsets.US_ASCII) == "#EXTM3U") {
            hls(url, String(inp.readBytes(), Charsets.UTF_8), filter)
        } else pipe(inp, filter)
    }

    private fun pipe(inp: InputStream, f: TsAudioFilter) {
        val buf = ByteArray(32 * 1024)
        while (true) {
            val r = inp.read(buf)
            if (r < 0) return
            f.feed(buf, 0, r)
        }
    }

    private fun fetchText(url: String): String =
        open(url).let { c -> try { c.inputStream.readBytes().toString(Charsets.UTF_8) } finally { c.disconnect() } }

    private fun resolve(base: String, ref: String) = URL(URL(base), ref.trim()).toString()

    private fun hls(first: String, firstBody: String, f: TsAudioFilter) {
        var plUrl = first
        var body = firstBody
        val seen = LinkedHashSet<String>()
        var errors = 0
        while (true) {
            val lines = body.lines()
            if (lines.any { it.startsWith("#EXT-X-STREAM-INF") }) {
                // أخف نسخة (أقل BANDWIDTH) لأننا نحتاج الصوت فقط
                var best: String? = null
                var bw = Long.MAX_VALUE
                var i = 0
                while (i < lines.size) {
                    if (lines[i].startsWith("#EXT-X-STREAM-INF")) {
                        val b = Regex("BANDWIDTH=(\\d+)").find(lines[i])?.groupValues?.get(1)?.toLongOrNull() ?: (Long.MAX_VALUE - 1)
                        var j = i + 1
                        while (j < lines.size && (lines[j].isBlank() || lines[j].startsWith("#"))) j++
                        if (j < lines.size && b < bw) { bw = b; best = lines[j] }
                        i = j
                    } else i++
                }
                plUrl = resolve(plUrl, best ?: throw IOException("no variants"))
                body = fetchText(plUrl)
                continue
            }
            if (lines.any { it.startsWith("#EXT-X-KEY") && !it.contains("METHOD=NONE") })
                throw IOException("encrypted")
            val target = Regex("#EXT-X-TARGETDURATION:(\\d+)").find(body)?.groupValues?.get(1)?.toIntOrNull() ?: 6
            val end = lines.any { it.startsWith("#EXT-X-ENDLIST") }
            val segs = lines.filter { it.isNotBlank() && !it.startsWith("#") }.map { resolve(plUrl, it) }
            val play = if (!end && seen.isEmpty()) segs.takeLast(3) else segs.filter { it !in seen }
            for (s in play) {
                seen.add(s)
                try {
                    val c = open(s)
                    try { c.inputStream.use { pipe(it, f) } } finally { c.disconnect() }
                } catch (e: IOException) { errors++ }
            }
            while (seen.size > 300) { val it = seen.iterator(); it.next(); it.remove() }
            if (end) return
            if (errors > 8) throw IOException("too many errors")
            Thread.sleep((target * 500L).coerceIn(1000L, 5000L))
            try { body = fetchText(plUrl) } catch (e: IOException) { errors++ }
        }
    }
}

/** سيرفر محلي صغير: يحوّل أي رابط قناة إلى رابط صوتي. */
object AudioServer {
    @Volatile var port = 0
    private var server: ServerSocket? = null

    @Synchronized
    fun start(): Int {
        if (server != null) return port
        var s: ServerSocket? = null
        for (p in 8899..8920) {
            try { s = ServerSocket(p); break } catch (e: IOException) { }
        }
        val ss = s ?: throw IOException("no port")
        server = ss
        port = ss.localPort
        thread(isDaemon = true) {
            while (!ss.isClosed) {
                val c = try { ss.accept() } catch (e: IOException) { break }
                thread(isDaemon = true) { handle(c) }
            }
        }
        return port
    }

    @Synchronized
    fun stop() {
        try { server?.close() } catch (e: IOException) { }
        server = null
        port = 0
    }

    val running get() = server != null

    fun link(host: String, source: String) =
        "http://$host:$port/audio.ts?u=" + URLEncoder.encode(source, "UTF-8")

    /** عنوان الواي فاي (إن وجد) لتشغيل الرابط من جهاز ثاني */
    fun lanIp(): String? = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it.address.size == 4 }?.hostAddress
    } catch (e: Exception) { null }

    private fun handle(sock: Socket) {
        try {
            sock.use {
                val rd = it.getInputStream().bufferedReader()
                val line = rd.readLine() ?: return
                while (true) { val h = rd.readLine(); if (h.isNullOrEmpty()) break }
                val parts = line.split(" ")
                val target = parts.getOrNull(1) ?: return
                val src = target.substringAfter('?', "").split('&')
                    .firstOrNull { q -> q.startsWith("u=") }?.substring(2)
                    ?.let { v -> URLDecoder.decode(v, "UTF-8") }
                val o = it.getOutputStream()
                if (!target.startsWith("/audio") || src == null || !src.startsWith("http", true)) {
                    o.write("HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n".toByteArray()); return
                }
                o.write(("HTTP/1.1 200 OK\r\nContent-Type: video/mp2t\r\nCache-Control: no-cache\r\n" +
                    "Connection: close\r\n\r\n").toByteArray())
                o.flush()
                if (parts[0] == "HEAD") return
                AudioRelay.stream(src, o)
            }
        } catch (e: ClientGone) {
        } catch (e: Exception) {
        }
    }
}
