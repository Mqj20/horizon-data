package com.tsconv.app

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * ===== مكان كود التشفير تبعك =====
 * لو عندك خوارزمية خاصة، بدّل محتوى encrypt() و decrypt() فقط، وباقي التطبيق يشتغل عليها كما هو.
 * الافتراضي هنا: AES-256-GCM بمفتاح مشتق من كلمة سر تكتبها في الشاشة.
 */
object LinkCrypto {
    const val PREFIX = "MQJ1:"
    /** المفتاح المدمج: يُستخدم تلقائياً لما تترك كلمة السر فاضية. غيّره لقيمة خاصة بك قبل البناء. */
    const val APP_KEY = "MQJ-change-this-secret-2026"
    private val salt = "mqj-m3u8-salt-v1".toByteArray()
    private var cachedPass: String? = null
    private var cachedKey: SecretKeySpec? = null

    private fun key(pass: String): SecretKeySpec {
        val pw = pass.ifEmpty { APP_KEY }
        if (pw == cachedPass && cachedKey != null) return cachedKey!!
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        val k = f.generateSecret(PBEKeySpec(pw.toCharArray(), salt, 20_000, 256)).encoded
        return SecretKeySpec(k, "AES").also { cachedPass = pw; cachedKey = it }
    }

    fun isEncrypted(s: String) = s.startsWith(PREFIX)

    /** تشفير ملف كامل (أي نوع) -> نص MQJ1:... جاهز للحفظ كملف نصي. */
    fun encryptBytes(data: ByteArray, pass: String): ByteArray {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(pass), GCMParameterSpec(128, iv))
        val ct = c.doFinal(data)
        return (PREFIX + Base64.encodeToString(iv + ct, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)).toByteArray(Charsets.US_ASCII)
    }

    /** فك تشفير ملف كامل. يرجع null لو كلمة السر خاطئة أو الملف تالف. */
    fun decryptBytes(data: ByteArray, pass: String): ByteArray? = try {
        val txt = String(data, Charsets.US_ASCII).trim().removePrefix(PREFIX)
        val raw = Base64.decode(txt, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(pass), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        c.doFinal(raw, 12, raw.size - 12)
    } catch (e: Exception) { null }

    fun looksEncrypted(data: ByteArray) =
        data.size > PREFIX.length && String(data, 0, PREFIX.length, Charsets.US_ASCII) == PREFIX

    fun encrypt(plain: String, pass: String): String {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(pass), GCMParameterSpec(128, iv))
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return PREFIX + Base64.encodeToString(iv + ct, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }

    /** يرجع null لو كلمة السر خاطئة أو النص تالف. */
    fun decrypt(enc: String, pass: String): String? = try {
        val raw = Base64.decode(enc.removePrefix(PREFIX), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(pass), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
    } catch (e: Exception) { null }

    /** يعالج نصاً كاملاً (أسطر رابط/اسم/#EXTINF). يرجع النص الناتج وعدد الأسطر الفاشلة. */
    fun process(text: String, pass: String, encrypt: Boolean, names: Boolean): Pair<String, Int> {
        var failed = 0
        fun one(s: String, isUrl: Boolean): String {
            if (s.isEmpty()) return s
            if (encrypt) {
                if (!isUrl && !names) return s
                return if (isEncrypted(s)) s else encrypt(s, pass)
            }
            if (!isEncrypted(s)) return s
            return decrypt(s, pass) ?: run { failed++; s }
        }
        val out = text.split("\n").joinToString("\n") { raw ->
            val l = raw.trimEnd('\r').trim()
            when {
                l.isEmpty() -> ""
                l.startsWith("#EXTINF", true) -> {
                    val i = l.indexOf(',')
                    if (i < 0) l else l.substring(0, i + 1) + one(l.substring(i + 1).trim(), false)
                }
                l.startsWith("#") -> l
                l.startsWith("http", true) -> one(l, true)
                else -> one(l, false)
            }
        }
        return out to failed
    }

    /** يستخرج (اسم، رابط) مفكوكين من نص فيه أسماء وروابط، مشفّرة أو عادية، أو M3U. */
    fun entries(src: String, pass: String): List<Pair<String?, String>> {
        val items = ArrayList<Pair<String?, String>>()
        var name: String? = null
        fun dec(s: String) = if (isEncrypted(s)) decrypt(s, pass) else s
        for (raw in src.split("\n")) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#EXTINF", true)) { name = dec(l.substringAfterLast(',', "").trim()); continue }
            if (l.startsWith("#")) continue
            val d = dec(l)
            if (d == null) { name = null; continue }
            if (d.startsWith("http", true)) { items.add(name to d); name = null } else name = d
        }
        return items
    }
}
