package com.tsconv.app

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/** تشفير روابط البث بنفس صيغة تطبيقي Horizon (GT للشاشات وTV للهواتف). ملف مستقل: ما يلمس بقية التطبيق. */
object HorizonCrypto {
    // المفاتيح هنا مطابقة تماماً لـ SecurityUtils.kt الحالي بتطبيقي TV وGT (مخفية بـ XOR مثل التطبيقين).
    // إذا غيّرت المفاتيح بالتطبيقين مستقبلاً، لازم تغيّرها هنا بنفس الوقت، وتعيد تشفير روابط content_v2.json.
    private val M = intArrayOf(0x5A, 0xC3, 0x17, 0x9E, 0x71, 0xB4, 0x2D, 0xE8)
    private fun unmask(a: IntArray): ByteArray = ByteArray(a.size) { (a[it] xor M[it % M.size]).toByte() }

    private val CBC_KEY = unmask(intArrayOf(0x12, 0xAC, 0x65, 0xF7, 0x0B, 0xDB, 0x43, 0xBB, 0x3F, 0xA0, 0x65, 0xFB, 0x05, 0x86, 0x1B, 0xC9))
    private val CBC_IV = unmask(intArrayOf(0x12, 0xAC, 0x65, 0xF7, 0x0B, 0xDB, 0x43, 0xA1, 0x34, 0xAA, 0x63, 0xC8, 0x14, 0xD7, 0x1C, 0xC9))
    private const val GCM_PREFIX = "HZ2:"
    private val GCM_KEY by lazy {
        SecretKeySpec(
            MessageDigest.getInstance("SHA-256")
                .digest(unmask(intArrayOf(0x12, 0xAC, 0x65, 0xF7, 0x0B, 0xDB, 0x43, 0xAF, 0x19, 0x8E, 0x34, 0xAC, 0x41, 0x86, 0x1B, 0xC5, 0x31, 0xA6, 0x6E))),
            "AES"
        )
    }

    /** فك GCM: يرجع null إذا المفتاح غلط أو الرابط تالف. */
    fun decryptGcm(s: String): String? = try {
        val raw = Base64.decode(s.trim().removePrefix(GCM_PREFIX), Base64.DEFAULT)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, GCM_KEY, GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
    } catch (e: Exception) { null }

    /** فك CBC القديم: يرجع null إذا مو مشفر بهالمفتاح. */
    fun decryptCbc(s: String): String? = try {
        val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(CBC_KEY, "AES"), IvParameterSpec(CBC_IV))
        String(c.doFinal(Base64.decode(s.trim(), Base64.DEFAULT)), Charsets.UTF_8)
    } catch (e: Exception) { null }

    fun encryptCbc(plain: String): String {
        val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(CBC_KEY, "AES"), IvParameterSpec(CBC_IV))
        return Base64.encodeToString(c.doFinal(plain.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    fun encryptGcm(plain: String): String {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, GCM_KEY, GCMParameterSpec(128, iv))
        return GCM_PREFIX + Base64.encodeToString(iv + c.doFinal(plain.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    private val QRX = Regex("(?i)(?<![A-Za-z0-9])(4K|UHD|2160P?|FHD|FULL\\s?HD|1080P?|720P?|HD|SD|480P?|360P?|H)(?![A-Za-z0-9])")

    /** يرجع (الاسم الأساسي، الجودة). الجودة تُؤخذ من آخر كلمة جودة بالاسم؛ تُشال من الاسم فقط لو كانت بآخره. */
    fun detect(name: String, def: String): Pair<String, String> {
        val n = name.trim()
        val m = QRX.findAll(n).lastOrNull() ?: return n to def
        val t = m.value.uppercase().replace(" ", "")
        val q = when {
            t == "4K" || t == "UHD" || t.startsWith("2160") -> "4K"
            t == "SD" || t.startsWith("480") || t.startsWith("360") -> "SD"
            else -> "HD"
        }
        val atEnd = n.substring(m.range.last + 1).isBlank()
        val base = if (atEnd) n.substring(0, m.range.first).trim().trimEnd('-', '—', '|', ':', '(', '[').trim() else n
        return (if (base.isEmpty()) n else base) to q
    }

    /** (اسم، رابط بث، لوغو) ← JSON لـ Horizon: الرابط فقط مشفر، الاسم واللوغو عاديان، والجودات مدموجة. */
    fun json(rows: List<Triple<String, String, String>>, gcm: Boolean): String =
        Export.json(Export.group(rows.map { Export.Row(it.first, it.second, it.third) }), Export.encoder(gcm))

    /** يحلل: اسم بسطر ورابط تحته، أو «الاسم | الرابط»، أو M3U. */
    fun parse(text: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        var name: String? = null
        val sep = Regex("^(.*?)\\s*[|\\t]\\s*(https?://\\S+)$", RegexOption.IGNORE_CASE)
        for (raw in text.split("\n")) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#EXTINF", true)) { name = l.substringAfterLast(',', "").trim(); continue }
            if (l.startsWith("#")) continue
            val m = sep.find(l)
            if (m != null) {
                out.add(m.groupValues[1].trim() to m.groupValues[2]); name = null
            } else if (l.startsWith("http", true)) {
                out.add((name ?: "قناة ${out.size + 1}") to l); name = null
            } else name = l
        }
        return out
    }
}

class HorizonCryptoActivity : Activity() {

    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var info: TextView
    private lateinit var gcmBtn: Button
    private lateinit var cbcBtn: Button
    private lateinit var qBtn: Button
    private var gcm = true
    private val qualities = listOf("HD", "SD", "4K", "Live")
    private var qi = 0
    private var results: List<Triple<String, String, String>> = emptyList()

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.bg
        window.navigationBarColor = Ui.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.bg)
            setPadding(dp(18), dp(30), dp(18), dp(24))
        }
        root.addView(Ui.label(this, "🔒  تشفير قنوات Horizon", 22f, Ui.gold), Ui.lp(this, 6))
        root.addView(Ui.label(this, "يطلّع روابط مشفرة يفهمها تطبيق GT (الشاشات) وTV (الهواتف)", 12f, Ui.textDim), Ui.lp(this, 12))

        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.round(this@HorizonCryptoActivity, Ui.card, 30, Ui.stroke)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        gcmBtn = pill("AES-256-GCM (الجديد)") { gcm = true; refreshMode() }
        cbcBtn = pill("AES-CBC (القديم)") { gcm = false; refreshMode() }
        seg.addView(gcmBtn, LinearLayout.LayoutParams(0, -2, 1f))
        seg.addView(cbcBtn, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(seg, Ui.lp(this, 10))

        qBtn = Ui.button(this, "", false) {
            qi = (qi + 1) % qualities.size; refreshMode()
        }
        root.addView(qBtn, Ui.lp(this, 10))

        root.addView(Ui.label(this, "المدخل: اسم القناة وتحته رابطها، أو «الاسم | الرابط»، أو M3U", 12f, Ui.textDim), Ui.lp(this, 4))
        input = EditText(this).apply {
            minLines = 6; maxLines = 10
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(Ui.textMain); setHintTextColor(Ui.textDim)
            hint = "قناة 1\nhttp://server/live/user/pass/1.m3u8"
            textSize = 14f
            background = Ui.round(this@HorizonCryptoActivity, Ui.card, 18, Ui.stroke)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(input, Ui.lp(this, 10))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.button(this, "لصق", false) { paste() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        row.addView(Ui.button(this, "تشفير", true) { run() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        row.addView(Ui.button(this, "مسح", false) { input.setText(""); output.text = ""; info.text = ""; results = emptyList() },
            LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row, Ui.lp(this, 14))

        root.addView(Ui.label(this, "النتيجة", 12f, Ui.textDim), Ui.lp(this, 4))
        output = TextView(this).apply {
            textSize = 13f; setTextColor(Ui.textMain)
            minLines = 6
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_LTR
            setTextIsSelectable(true)
            background = Ui.round(this@HorizonCryptoActivity, Ui.card, 18, Ui.stroke)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(output, Ui.lp(this, 8))
        info = Ui.label(this, "", 12f, Ui.textDim).apply { gravity = Gravity.CENTER }
        root.addView(info, Ui.lp(this, 12))

        root.addView(Ui.button(this, "نسخ (اسم + رابط مشفر)", false) {
            if (output.text.isNotEmpty()) { Ui.copy(this, output.text.toString()); toast("تم النسخ") }
        }, Ui.lp(this, 10))
        root.addView(Ui.button(this, "📋  نسخ JSON للصقه بـ content_v2.json", true) { copyJson() }, Ui.lp(this, 10))
        root.addView(Ui.button(this, "📂  فحص ملف content_v2.json وتشفير الروابط غير المشفرة", false) { pickFile() }, Ui.lp(this, 0))

        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.bg); isFillViewport = true; addView(root) })
        refreshMode()
        if (intent.getBooleanExtra("pick", false)) pickFile()
    }

    private fun pill(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 12f; stateListAnimator = null
        setOnClickListener { onClick() }
    }

    private fun refreshMode() {
        fun style(b: Button, on: Boolean) {
            b.setTextColor(if (on) android.graphics.Color.parseColor("#1A1405") else Ui.textDim)
            b.background = if (on) Ui.round(this, Ui.gold, 26) else null
        }
        style(gcmBtn, gcm); style(cbcBtn, !gcm)
        qBtn.text = "الجودة الافتراضية (لو ما مكتوبة بالاسم): ${qualities[qi]}"
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)
        if (!t.isNullOrEmpty()) input.setText(t)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun run() {
        val items = HorizonCrypto.parse(input.text.toString())
        if (items.isEmpty()) { toast("ما لقيت روابط، تأكد من الصيغة"); return }
        val def = qualities[qi]
        results = try {
            items.map { (n, u) ->
                val (base, q) = HorizonCrypto.detect(n, def)
                Triple(base, q, if (gcm) HorizonCrypto.encryptGcm(u) else HorizonCrypto.encryptCbc(u))
            }
        } catch (e: Exception) { toast("فشل التشفير"); return }
        output.text = results.joinToString("\n\n") { (b, q, e) -> "$b  [$q]\n$e" }
        val ch = results.map { it.first.lowercase().replace(Regex("\\s+"), " ") }.distinct().size
        info.text = "تم تشفير ${results.size} رابط ($ch قناة)"
    }

    private fun copyJson() {
        if (results.isEmpty()) run()
        if (results.isEmpty()) return
        // دمج الجودات: نفس الاسم الأساسي = قناة وحدة، وكل جودة مفتاح بـ streams. تكرار نفس الجودة = سيرفر بديل.
        val groups = LinkedHashMap<String, Pair<String, LinkedHashMap<String, MutableList<String>>>>()
        results.forEach { (b, q, e) ->
            val k = b.lowercase().replace(Regex("\\s+"), " ")
            val g = groups.getOrPut(k) { b to LinkedHashMap() }
            g.second.getOrPut(q) { mutableListOf() }.add(e)
        }
        val arr = JSONArray()
        groups.values.forEach { (name, qs) ->
            val st = JSONObject()
            qs.forEach { (q, list) -> st.put(q, if (list.size == 1) list[0] else JSONArray(list)) }
            arr.put(JSONObject().put("name", name).put("logo", "").put("streams", st))
        }
        try { Ui.copy(this, arr.toString(2)); toast("تم نسخ JSON (${groups.size} قناة)") }
        catch (e: Exception) { toast("الحجم كبير على النسخ") }
    }

    // ===== فحص ملف content_v2.json: يعدّل روابط streams فقط داخل نص الملف نفسه (بدون إعادة كتابته) =====
    private class Scan {
        var ok = 0; var enc = 0; var bad = 0; var unknown = 0; var placeholder = 0
        val review = ArrayList<String>()
    }

    private class Frame(val isObj: Boolean, val inStreams: Boolean) {
        var expectKey = isObj
    }

    private var fixedJson: String? = null

    private fun decodeJson(raw: String): String =
        if (!raw.contains('\\')) raw
        else try { JSONArray("[\"" + raw + "\"]").getString(0) } catch (e: Exception) { raw }

    /** يرجع الرابط المشفر إذا لازم يتغير، أو null إذا يبقى كما هو. */
    private fun fixStream(value: String, st: Scan, where: String): String? {
        val s = value.trim()
        return when {
            s.isEmpty() -> null
            s.startsWith("HZ2:") -> {
                if (HorizonCrypto.decryptGcm(s) != null) st.ok++
                else { st.bad++; st.review.add("$where  (HZ2 ما ينفك بالمفتاح الحالي)") }
                null
            }
            s.startsWith("http://", true) || s.startsWith("https://", true) -> {
                if (s.contains("example.com", true) || s.contains("REPLACE", true)) { st.placeholder++; null }
                else { st.enc++; HorizonCrypto.encryptGcm(s) }
            }
            else -> {
                val d = HorizonCrypto.decryptCbc(s)
                if (d != null && d.startsWith("http", true)) st.ok++
                else { st.unknown++; st.review.add("$where  (صيغة غير مفهومة)") }
                null
            }
        }
    }

    /** يمشي على نص الملف حرف حرف، ويبدّل فقط النصوص الحرفية اللي داخل "streams". كل شي ثاني يبقى بايت ببايت. */
    private fun rewrite(text: String, st: Scan): String {
        val out = StringBuilder(text.length + 4096)
        val stack = ArrayList<Frame>()
        var pendingKey = ""
        var lastName = ""
        var lastQ = ""
        var copied = 0
        var i = 0
        val n = text.length
        while (i < n) {
            val ch = text[i]
            if (ch == '"') {
                var j = i + 1
                while (j < n && text[j] != '"') { if (text[j] == '\\') j++; j++ }
                if (j >= n) break
                val raw = text.substring(i + 1, j)
                val top = if (stack.isEmpty()) null else stack[stack.size - 1]
                if (top != null && top.isObj && top.expectKey) {
                    pendingKey = decodeJson(raw)
                    top.expectKey = false
                    if (top.inStreams) lastQ = pendingKey
                } else if (top != null && top.inStreams) {
                    val repl = fixStream(decodeJson(raw), st, "$lastName / $lastQ")
                    if (repl != null) {
                        out.append(text, copied, i)
                        out.append('"').append(repl).append('"')
                        copied = j + 1
                    }
                } else if (top != null && top.isObj && pendingKey == "name") {
                    lastName = decodeJson(raw)
                }
                i = j + 1
                continue
            }
            if (ch == '{' || ch == '[') {
                val parentIn = stack.isNotEmpty() && stack[stack.size - 1].inStreams
                stack.add(Frame(ch == '{', parentIn || pendingKey == "streams"))
                pendingKey = ""
            } else if (ch == '}' || ch == ']') {
                if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
                pendingKey = ""
            } else if (ch == ',') {
                if (stack.isNotEmpty() && stack[stack.size - 1].isObj) stack[stack.size - 1].expectKey = true
                pendingKey = ""
            }
            i++
        }
        out.append(text, copied, n)
        return out.toString()
    }

    private fun pickFile() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }, REQ_OPEN)
    }

    private fun scanFile(uri: android.net.Uri) {
        val text = try { contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } } catch (e: Exception) { null }
        if (text.isNullOrBlank()) { toast("تعذّرت قراءة الملف"); return }
        try { JSONObject(text.trimStart('\uFEFF').trim()) } catch (e: Exception) { toast("الملف مو JSON صالح"); return }
        val st = Scan()
        val result = rewrite(text, st)
        // حماية: الناتج لازم يكون JSON صالح، وإلا ما يُحفظ شي
        try { JSONObject(result.trimStart('\uFEFF').trim()) } catch (e: Exception) { toast("صار خطأ بالمعالجة، ما حفظت شي"); return }
        val sb = StringBuilder()
        sb.append("روابط مشفرة وسليمة: ${st.ok}\n")
        sb.append("روابط غير مشفرة (تم تشفيرها الآن): ${st.enc}\n")
        if (st.placeholder > 0) sb.append("روابط نموذجية (example/REPLACE) تركتها: ${st.placeholder}\n")
        if (st.bad > 0) sb.append("روابط HZ2 ما تنفك بالمفتاح الحالي: ${st.bad}\n")
        if (st.unknown > 0) sb.append("روابط بصيغة غير مفهومة: ${st.unknown}\n")
        if (st.review.isNotEmpty()) sb.append("\nتحتاج مراجعة:\n" + st.review.take(30).joinToString("\n"))
        output.text = sb.toString()
        info.text = "عدّلت روابط streams فقط. الترتيب والأسماء والشعارات وكل شي ثاني بقى مثل الأصل بالضبط."
        if (st.enc == 0) { fixedJson = null; toast("ما فيه روابط تحتاج تشفير، الملف ما تغيّر"); return }
        fixedJson = result
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "content_v2.json")
        }, REQ_SAVE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_OPEN -> scanFile(uri)
            REQ_SAVE -> {
                val txt = fixedJson ?: return
                try {
                    contentResolver.openOutputStream(uri, "wt")?.use { it.write(txt.toByteArray(Charsets.UTF_8)) }
                    toast("تم حفظ الملف المصحّح")
                } catch (e: Exception) { toast("تعذّر الحفظ") }
            }
        }
    }

    companion object {
        private const val REQ_OPEN = 9101
        private const val REQ_SAVE = 9102
    }
}
