package com.tsconv.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast

/** تسجيل الدخول لحساب Xtream + عرض الباقات. زر ⋮ بجانب كل باقة لنسخ أسماء القنوات مع روابط بثها. */
class XtreamActivity : Activity() {

    private lateinit var server: android.widget.EditText
    private lateinit var user: android.widget.EditText
    private lateinit var pass: android.widget.EditText
    private lateinit var filter: android.widget.EditText
    private lateinit var status: TextView
    private lateinit var extBtn: android.widget.Button
    private lateinit var list: ListView

    private var creds: XtreamApi.Creds? = null
    private var all: List<XtreamApi.Cat> = emptyList()
    private val shown = ArrayList<XtreamApi.Cat>()

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun ext() = Ui.prefs(this).getString("ext", "m3u8") ?: "m3u8"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.bg
        window.navigationBarColor = Ui.bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.bg)
            setPadding(dp(18), dp(30), dp(18), dp(14))
        }

        root.addView(Ui.label(this, "📡  باقات الاكستريم", 22f, Ui.gold), Ui.lp(this, 14))

        server = Ui.field(this, "السيرفر  http://host:port  أو رابط get.php كامل")
        user = Ui.field(this, "اسم المستخدم")
        pass = Ui.field(this, "كلمة المرور", password = true)
        root.addView(server, Ui.lp(this, 8))
        root.addView(user, Ui.lp(this, 8))
        root.addView(pass, Ui.lp(this, 10))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.button(this, "اتصال", true) { connect() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
        extBtn = Ui.button(this, "", false) {
            val n = if (ext() == "m3u8") "ts" else "m3u8"
            Ui.prefs(this).edit().putString("ext", n).apply()
            refreshExt()
        }
        row.addView(extBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row, Ui.lp(this, 8))
        refreshExt()

        status = Ui.label(this, "", 12f, Ui.textDim).apply { gravity = Gravity.CENTER }
        root.addView(status, Ui.lp(this, 8))

        filter = Ui.field(this, "🔍  بحث في الباقات").apply { visibility = View.GONE }
        filter.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { applyFilter() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        root.addView(filter, Ui.lp(this, 8))

        list = ListView(this).apply {
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(8)
            adapter = Adapter()
            setOnItemClickListener { _, _, pos, _ -> openCategory(shown[pos]) }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)

        // البيانات المحفوظة من آخر مرة
        val p = Ui.prefs(this)
        val fromList = intent.getStringExtra("acct_base")
        if (fromList != null) {
            // جاي من قائمة الحسابات المحفوظة
            server.setText(fromList)
            user.setText(intent.getStringExtra("acct_user") ?: "")
            pass.setText(intent.getStringExtra("acct_pass") ?: "")
        } else {
            server.setText(p.getString("server", ""))
            user.setText(p.getString("user", ""))
            pass.setText(p.getString("pass", ""))
        }
        if (server.text.isNotBlank() && user.text.isNotBlank()) connect()
    }

    private fun refreshExt() {
        extBtn.text = "الصيغة:  .${ext()}"
    }

    private fun connect() {
        val parsed = XtreamApi.parseServer(server.text.toString())
        if (parsed == null) {
            status.text = "اكتب عنوان السيرفر"
            return
        }
        // لو لصقت رابط get.php كامل نعبّي المستخدم والباسورد تلقائياً
        if (user.text.isBlank() && parsed.user.isNotEmpty()) user.setText(parsed.user)
        if (pass.text.isBlank() && parsed.pass.isNotEmpty()) pass.setText(parsed.pass)
        val c = XtreamApi.Creds(parsed.base, user.text.toString().trim(), pass.text.toString().trim())
        if (c.user.isEmpty() || c.pass.isEmpty()) {
            status.text = "اكتب اسم المستخدم وكلمة المرور"
            return
        }
        status.text = "جارٍ الاتصال..."
        Thread {
            try {
                val info = XtreamApi.login(c)
                val cats = XtreamApi.categories(c)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    creds = c
                    Ui.prefs(this).edit()
                        .putString("server", c.base).putString("user", c.user).putString("pass", c.pass)
                        .apply()
                    server.setText(c.base)
                    AccountStore.upsert(this, c, info)
                    all = cats
                    filter.visibility = View.VISIBLE
                    applyFilter()
                    status.text = "$info  •  ${cats.size} باقة"
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "فشل الاتصال: ${e.message ?: e.javaClass.simpleName}" }
            }
        }.start()
    }

    private fun applyFilter() {
        val q = filter.text.toString().trim().lowercase()
        shown.clear()
        shown.addAll(if (q.isEmpty()) all else all.filter { it.name.lowercase().contains(q) })
        (list.adapter as BaseAdapter).notifyDataSetChanged()
    }

    private fun openCategory(cat: XtreamApi.Cat) {
        val c = creds ?: return
        startActivity(
            Intent(this, ChannelsActivity::class.java)
                .putExtra("base", c.base).putExtra("user", c.user).putExtra("pass", c.pass)
                .putExtra("catId", cat.id).putExtra("catName", cat.name)
        )
    }

    private fun showMenu(anchor: View, cat: XtreamApi.Cat) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "نسخ أسماء القنوات مع روابط بثها")
        m.menu.add(0, 2, 1, "نسخ كقائمة M3U")
        m.menu.add(0, 3, 2, "فتح الباقة")
        m.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> copyCategory(cat, false)
                2 -> copyCategory(cat, true)
                3 -> openCategory(cat)
            }
            true
        }
        m.show()
    }

    private fun copyCategory(cat: XtreamApi.Cat, m3u: Boolean) {
        val c = creds ?: return
        Toast.makeText(this, "جارٍ جلب القنوات...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val chs = XtreamApi.channels(c, cat.id)
                if (chs.isEmpty()) {
                    runOnUiThread { Toast.makeText(this, "الباقة فاضية", Toast.LENGTH_SHORT).show() }
                    return@Thread
                }
                val text = if (m3u) XtreamApi.asM3u(c, chs, ext()) else XtreamApi.namesWithLinks(c, chs, ext())
                runOnUiThread {
                    try {
                        Ui.copy(this, text)
                        Toast.makeText(this, "تم نسخ ${chs.size} قناة مع روابطها", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "الباقة كبيرة جداً للنسخ", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "فشل: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val cat = shown[position]
            val row = LinearLayout(this@XtreamActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = Ui.ripple(Ui.round(this@XtreamActivity, Ui.card, 14, Ui.stroke))
                setPadding(dp(16), 0, dp(4), 0)
                minimumHeight = dp(54)
            }
            row.addView(TextView(this@XtreamActivity).apply {
                text = cat.name
                textSize = 15f
                setTextColor(Ui.textMain)
                maxLines = 2
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(this@XtreamActivity).apply {
                text = "⋮"
                textSize = 24f
                setTextColor(Ui.gold)
                gravity = Gravity.CENTER
                setOnClickListener { showMenu(this, cat) }
            }, LinearLayout.LayoutParams(dp(52), dp(54)))
            return row
        }
    }
}
