package com.tsconv.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** حقلان: المدخل (روابط بدون تشفير) ← المخرج (روابط مشفّرة)، والعكس. مع تشغيل الروابط بعد فك التشفير. */
class CryptoActivity : Activity() {

    private lateinit var pass: EditText
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var info: TextView
    private lateinit var namesBox: CheckBox
    private var encryptMode = true
    private lateinit var encBtn: android.widget.Button
    private lateinit var decBtn: android.widget.Button

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.bg
        window.navigationBarColor = Ui.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.bg)
            setPadding(dp(18), dp(30), dp(18), dp(24))
        }
        root.addView(Ui.label(this, "🔐  تشفير الروابط", 22f, Ui.gold), Ui.lp(this, 12))

        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.round(this@CryptoActivity, Ui.card, 30, Ui.stroke)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        encBtn = pill("تشفير") { encryptMode = true; refreshMode() }
        decBtn = pill("فك التشفير") { encryptMode = false; refreshMode() }
        seg.addView(encBtn, LinearLayout.LayoutParams(0, -2, 1f))
        seg.addView(decBtn, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(seg, Ui.lp(this, 12))

        pass = Ui.field(this, "كلمة سر (اختياري - الفاضي = المفتاح المدمج)", password = true)
        pass.setText(Ui.prefs(this).getString("cpass", ""))
        root.addView(pass, Ui.lp(this, 6))

        namesBox = CheckBox(this).apply {
            text = "تشفير أسماء القنوات أيضاً"
            setTextColor(Ui.textMain)
            isChecked = true
        }
        root.addView(namesBox, Ui.lp(this, 10))

        root.addView(Ui.label(this, "المدخل", 12f, Ui.textDim), Ui.lp(this, 4))
        input = EditText(this).apply {
            minLines = 5; maxLines = 8
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(Ui.textMain); setHintTextColor(Ui.textDim)
            hint = "الصق أسماء القنوات وروابطها أو قائمة M3U"
            textSize = 14f
            background = Ui.round(this@CryptoActivity, Ui.card, 18, Ui.stroke)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(input, Ui.lp(this, 10))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.button(this, "لصق", false) { paste() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        row.addView(Ui.button(this, "تنفيذ", true) { run() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        row.addView(Ui.button(this, "مسح", false) { input.setText(""); output.text = ""; info.text = "" },
            LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row, Ui.lp(this, 14))

        root.addView(Ui.label(this, "النتيجة", 12f, Ui.textDim), Ui.lp(this, 4))
        output = TextView(this).apply {
            textSize = 14f; setTextColor(Ui.textMain)
            minLines = 5
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_LTR
            setTextIsSelectable(true)
            background = Ui.round(this@CryptoActivity, Ui.card, 18, Ui.stroke)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(output, Ui.lp(this, 8))
        info = Ui.label(this, "", 12f, Ui.textDim).apply { gravity = Gravity.CENTER }
        root.addView(info, Ui.lp(this, 12))

        root.addView(Ui.button(this, "▶   تشغيل (يفك التشفير تلقائياً)", true) { play() }, Ui.lp(this, 10))
        root.addView(Ui.button(this, "نسخ النتيجة", false) {
            if (output.text.isNotEmpty()) { Ui.copy(this, output.text.toString()); toast("تم النسخ") }
        }, Ui.lp(this, 10))
        root.addView(Ui.button(this, "📤  تصدير connect.json للقنوات", false) { exportJson() }, Ui.lp(this, 0))

        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.bg); isFillViewport = true; addView(root) })
        refreshMode()
    }

    private fun pill(t: String, onClick: () -> Unit) = android.widget.Button(this).apply {
        text = t; isAllCaps = false; textSize = 13f; stateListAnimator = null
        setOnClickListener { onClick() }
    }

    private fun refreshMode() {
        fun style(b: android.widget.Button, on: Boolean) {
            b.setTextColor(if (on) android.graphics.Color.parseColor("#1A1405") else Ui.textDim)
            b.background = if (on) Ui.round(this, Ui.gold, 26) else null
        }
        style(encBtn, encryptMode); style(decBtn, !encryptMode)
        namesBox.visibility = if (encryptMode) View.VISIBLE else View.GONE
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)
        if (!t.isNullOrEmpty()) input.setText(t)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun run() {
        val p = pass.text.toString()
        Ui.prefs(this).edit().putString("cpass", p).apply()
        val (res, failed) = LinkCrypto.process(input.text.toString(), p, encryptMode, namesBox.isChecked)
        output.text = res
        info.text = when {
            res.isBlank() -> ""
            failed > 0 -> "$failed سطر ما انفك (كلمة السر خاطئة؟)"
            encryptMode -> "تم التشفير"
            else -> "تم فك التشفير"
        }
    }

    private fun play() {
        val p = pass.text.toString()
        // المصدر: النتيجة لو فيها شي، وإلا المدخل. أي سطر مشفّر يُفك أولاً.
        val src = output.text.toString().ifBlank { input.text.toString() }
        val items = LinkCrypto.entries(src, p)
        when {
            items.isEmpty() -> toast("ما لقيت رابط قابل للتشغيل (تأكد من كلمة السر)")
            items.size == 1 -> open(items[0].second)
            else -> AlertDialog.Builder(this).setTitle("اختر ما تريد تشغيله")
                .setItems(items.mapIndexed { i, (n, u) -> "${i + 1}.  ${n ?: ConverterActivity.maskLine(u)}" }.toTypedArray()) { _, w ->
                    open(items[w].second)
                }.show()
        }
    }

    private fun open(url: String) = startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", url))

    /** يبني connect.json من المدخل/النتيجة: الاسم والرابط مشفّران، جاهز للرفع على GitHub. */
    private fun exportJson() {
        val p = pass.text.toString()
        val src = input.text.toString().ifBlank { output.text.toString() }
        val items = LinkCrypto.entries(src, p)
        if (items.isEmpty()) { toast("ما لقيت قنوات (تأكد من كلمة السر)"); return }
        val arr = org.json.JSONArray()
        items.forEachIndexed { i, (n, u) ->
            arr.put(org.json.JSONObject()
                .put("name", LinkCrypto.encrypt(n ?: "قناة ${i + 1}", p))
                .put("url", LinkCrypto.encrypt(u, p)))
        }
        val json = org.json.JSONObject().put("channels", arr).toString(2)
        try { Ui.copy(this, json); toast("تم نسخ connect.json (${items.size} قناة)") }
        catch (e: Exception) { toast("الملف كبير على النسخ، استخدم المشاركة") }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, json)
        }, "مشاركة connect.json"))
    }
}
