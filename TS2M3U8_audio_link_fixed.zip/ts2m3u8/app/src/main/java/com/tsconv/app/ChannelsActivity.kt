package com.tsconv.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/** قنوات باقة واحدة. الضغط على قناة يعرض رابط بثها وزر تشغيل في المشغّل الداخلي (Media3). */
class ChannelsActivity : ExportActivity() {

    private lateinit var creds: XtreamApi.Creds
    private lateinit var info: TextView
    private lateinit var filter: android.widget.EditText
    private lateinit var list: ListView

    private var all: List<XtreamApi.Ch> = emptyList()
    private val shown = ArrayList<XtreamApi.Ch>()

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun ext() = Ui.prefs(this).getString("ext", "m3u8") ?: "m3u8"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.bg
        window.navigationBarColor = Ui.bg

        creds = XtreamApi.Creds(
            intent.getStringExtra("base") ?: "",
            intent.getStringExtra("user") ?: "",
            intent.getStringExtra("pass") ?: ""
        )
        val catId = intent.getStringExtra("catId") ?: ""
        val catName = intent.getStringExtra("catName") ?: ""

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.bg)
            setPadding(dp(18), dp(30), dp(18), dp(14))
        }
        root.addView(Ui.label(this, catName, 20f, Ui.gold).apply { maxLines = 2 }, Ui.lp(this, 6))
        info = Ui.label(this, "جارٍ جلب القنوات...", 12f, Ui.textDim)
        root.addView(info, Ui.lp(this, 10))

        root.addView(exportPanel {
            all.map { Export.Row(it.name, XtreamApi.link(creds, it, ext()), it.logo) }
        }, Ui.lp(this, 12))

        filter = Ui.field(this, "🔍  بحث في القنوات")
        filter.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { applyFilter() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        root.addView(filter, Ui.lp(this, 8))

        list = ListView(this).apply {
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(8)
            adapter = Adapter()
            setOnItemClickListener { _, _, pos, _ -> showChannel(shown[pos]) }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        Thread {
            try {
                val chs = XtreamApi.channels(creds, catId)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    all = chs
                    info.text = "${chs.size} قناة"
                    applyFilter()
                }
            } catch (e: Exception) {
                runOnUiThread { info.text = "فشل الجلب: ${e.message ?: e.javaClass.simpleName}" }
            }
        }.start()
    }

    private fun applyFilter() {
        val q = filter.text.toString().trim().lowercase()
        shown.clear()
        shown.addAll(if (q.isEmpty()) all else all.filter { it.name.lowercase().contains(q) })
        (list.adapter as BaseAdapter).notifyDataSetChanged()
    }

    private fun showChannel(ch: XtreamApi.Ch) {
        val url = XtreamApi.link(creds, ch, ext())
        var revealed = false
        val dlg = AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setMessage(ConverterActivity.maskLine(url) + (if (ch.logo.isNotBlank()) "\n\nاللوغو:\n${ch.logo}" else "\n\n(بدون لوغو)"))
            .setPositiveButton("▶  تشغيل") { _, _ ->
                startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", url))
            }
            .setNeutralButton("نسخ الكل") { _, _ ->
                Ui.copy(this, "${ch.name}\n$url" + (if (ch.logo.isNotBlank()) "\n${ch.logo}" else ""))
                Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("إظهار الرابط", null)
            .create()
        dlg.show()
        // زر الإظهار يبدّل العرض بدون إغلاق النافذة
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
            revealed = !revealed
            val lg = if (ch.logo.isNotBlank()) "\n\nاللوغو:\n${ch.logo}" else "\n\n(بدون لوغو)"
            dlg.setMessage((if (revealed) url else ConverterActivity.maskLine(url)) + lg)
            dlg.getButton(AlertDialog.BUTTON_NEGATIVE).text = if (revealed) "إخفاء الرابط" else "إظهار الرابط"
        }
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val ch = shown[position]
            return TextView(this@ChannelsActivity).apply {
                text = ch.name
                textSize = 15f
                setTextColor(Ui.textMain)
                gravity = Gravity.CENTER_VERTICAL
                maxLines = 2
                background = Ui.ripple(Ui.round(this@ChannelsActivity, Ui.card, 14, Ui.stroke))
                setPadding(dp(16), dp(14), dp(16), dp(14))
            }
        }
    }
}
