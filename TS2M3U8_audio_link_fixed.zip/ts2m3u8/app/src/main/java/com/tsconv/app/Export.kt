package com.tsconv.app

import org.json.JSONArray
import org.json.JSONObject

/** تجميع القنوات (الجودات بقناة وحدة) وتوليد النصوص المنفصلة وملف JSON. اللوغو دائماً بدون تشفير. */
object Export {
    data class Row(val name: String, val url: String, val logo: String)
    class Group(val name: String, var logo: String, val streams: LinkedHashMap<String, MutableList<String>>)

    private val ORDER = listOf("4K", "HD", "SD")

    fun group(rows: List<Row>): List<Group> {
        val map = LinkedHashMap<String, Group>()
        rows.forEach { r ->
            val (base, q) = HorizonCrypto.detect(r.name, "HD")
            val k = base.lowercase().replace(Regex("\\s+"), " ")
            val g = map.getOrPut(k) { Group(base, "", LinkedHashMap()) }
            if (g.logo.isBlank() && r.logo.isNotBlank()) g.logo = r.logo
            g.streams.getOrPut(q) { mutableListOf() }.add(r.url)
        }
        return map.values.toList()
    }

    private fun streams(g: Group): List<Pair<String, String>> =
        g.streams.entries
            .sortedBy { e -> ORDER.indexOf(e.key).let { if (it < 0) 99 else it } }
            .flatMap { (q, l) -> l.map { q to it } }

    private fun urlLines(g: Group, enc: ((String) -> String)?): String {
        val s = streams(g)
        fun v(u: String) = if (enc != null) enc(u) else u
        return if (s.size == 1) v(s[0].second) else s.joinToString("\n") { (q, u) -> "[$q] ${v(u)}" }
    }

    /** أسماء القنوات فقط، فاصل بين كل قناة وقناة. */
    fun names(gs: List<Group>) = gs.joinToString("\n\n") { it.name }

    /** الروابط فقط. القناة متعددة الجودات تطلع روابطها كل وحدة بسطر مع علامة جودتها. */
    fun urls(gs: List<Group>, enc: ((String) -> String)? = null) =
        gs.joinToString("\n\n") { urlLines(it, enc) }

    /** روابط اللوغوات فقط. */
    fun logos(gs: List<Group>) = gs.joinToString("\n\n") { it.logo.ifBlank { "(بدون لوغو)" } }

    /** اسم عادي + رابط مشفر + لوغو عادي، وفاصل بين القنوات. */
    fun encBlocks(gs: List<Group>, enc: (String) -> String) =
        gs.joinToString("\n\n") { g ->
            g.name + "\n" + urlLines(g, enc) + (if (g.logo.isNotBlank()) "\n" + g.logo else "")
        }

    /** JSON لـ content_v2.json: الاسم واللوغو عاديان، وروابط البث فقط مشفرة. */
    fun json(gs: List<Group>, enc: (String) -> String): String {
        val arr = JSONArray()
        gs.forEach { g ->
            val st = JSONObject()
            g.streams.entries
                .sortedBy { e -> ORDER.indexOf(e.key).let { if (it < 0) 99 else it } }
                .forEach { (q, list) ->
                    val e = list.map(enc)
                    st.put(q, if (e.size == 1) e[0] else JSONArray(e))
                }
            arr.put(JSONObject().put("name", g.name).put("logo", g.logo).put("streams", st))
        }
        return arr.toString(2)
    }

    fun encoder(gcm: Boolean): (String) -> String =
        { s -> if (s.isBlank()) "" else if (gcm) HorizonCrypto.encryptGcm(s) else HorizonCrypto.encryptCbc(s) }
}
