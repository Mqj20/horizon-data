package com.tsconv.app

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** التعامل مع واجهة Xtream (player_api.php) لحسابك أنت: الباقات، القنوات، وروابط البث. */
object XtreamApi {

    data class Creds(val base: String, val user: String, val pass: String)
    data class Cat(val id: String, val name: String)
    data class Ch(val id: String, val name: String, val logo: String = "")

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** يقبل: host:port أو http://host:port أو رابط get.php كامل (يلتقط منه المستخدم والباسورد). */
    fun parseServer(raw: String): Creds? {
        var s = raw.trim()
        if (s.isEmpty()) return null
        if (!s.contains("://")) s = "http://$s"
        val u = Uri.parse(s)
        val host = u.host ?: return null
        val port = if (u.port > 0) ":${u.port}" else ""
        val scheme = u.scheme ?: "http"
        return Creds(
            "$scheme://$host$port",
            u.getQueryParameter("username") ?: "",
            u.getQueryParameter("password") ?: ""
        )
    }

    private fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15_000
            c.readTimeout = 40_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "VLC/3.0.20 LibVLC/3.0.20")
            val code = c.responseCode
            if (code !in 200..299) throw Exception("رمز السيرفر: $code")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun api(c: Creds, action: String?, extra: String = ""): String =
        http(
            "${c.base}/player_api.php?username=${enc(c.user)}&password=${enc(c.pass)}" +
                (if (action != null) "&action=$action" else "") + extra
        )

    /** يتحقق من الحساب، ويرجع نصاً عن تاريخ الانتهاء. */
    fun login(c: Creds): String {
        val txt = api(c, null).trim()
        if (!txt.startsWith("{")) throw Exception("الرد غير مفهوم، تأكد من عنوان السيرفر")
        val info = JSONObject(txt).optJSONObject("user_info")
            ?: throw Exception("بيانات الدخول غير صحيحة")
        if (info.optString("auth") != "1") throw Exception("بيانات الدخول غير صحيحة")
        val status = info.optString("status")
        if (status.equals("Expired", true)) throw Exception("الاشتراك منتهٍ")
        val exp = info.optString("exp_date")
        val secs = exp.toLongOrNull()
        return if (secs != null && secs > 0)
            "ينتهي: " + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(secs * 1000))
        else "متصل"
    }

    fun categories(c: Creds): List<Cat> {
        val txt = api(c, "get_live_categories").trim()
        if (!txt.startsWith("[")) throw Exception("ما رجع السيرفر قائمة باقات")
        val arr = JSONArray(txt)
        val out = ArrayList<Cat>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Cat(o.optString("category_id"), o.optString("category_name")))
        }
        return out
    }

    fun channels(c: Creds, catId: String): List<Ch> {
        val txt = api(c, "get_live_streams", "&category_id=${enc(catId)}").trim()
        if (!txt.startsWith("[")) return emptyList()
        val arr = JSONArray(txt)
        val out = ArrayList<Ch>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Ch(o.optString("stream_id"), o.optString("name"), o.optString("stream_icon").trim()))
        }
        return out
    }

    fun link(c: Creds, ch: Ch, ext: String) = "${c.base}/live/${c.user}/${c.pass}/${ch.id}.$ext"

    /** اسم القناة ثم تحته رابط بثها، لكل القنوات. */
    fun namesWithLinks(c: Creds, list: List<Ch>, ext: String): String =
        list.joinToString("\n\n") { "${it.name}\n${link(c, it, ext)}" + (if (it.logo.isNotBlank()) "\n${it.logo}" else "") }

    fun asM3u(c: Creds, list: List<Ch>, ext: String): String =
        list.withIndex().joinToString("\n") { (i, ch) ->
            "#EXTINF:-1" + (if (ch.logo.isNotBlank()) " tvg-logo=\"${ch.logo}\"" else "") + ",${ch.name.ifBlank { "قناة ${i + 1}" }}\n${link(c, ch, ext)}"
        }
}
