package com.tsconv.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** أدوات واجهة مشتركة بنفس ألوان التطبيق (أسود + ذهبي). */
object Ui {
    val bg = Color.parseColor("#0B0B10")
    val card = Color.parseColor("#15151D")
    val stroke = Color.parseColor("#2B2B38")
    val gold = Color.parseColor("#D4AF37")
    val textMain = Color.parseColor("#F2EEE3")
    val textDim = Color.parseColor("#8C8A94")

    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun round(ctx: Context, fill: Int, radius: Int, strokeColor: Int? = null) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(ctx, radius).toFloat()
        if (strokeColor != null) setStroke(dp(ctx, 1), strokeColor)
    }

    fun ripple(content: GradientDrawable) =
        RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), content, null)

    fun button(ctx: Context, t: String, primary: Boolean, onClick: () -> Unit) = Button(ctx).apply {
        text = t
        isAllCaps = false
        textSize = 15f
        stateListAnimator = null
        setTextColor(if (primary) Color.parseColor("#1A1405") else textMain)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        background = ripple(if (primary) round(ctx, gold, 16) else round(ctx, card, 16, stroke))
        minHeight = dp(ctx, 48)
        setOnClickListener { onClick() }
    }

    fun field(ctx: Context, hintText: String, password: Boolean = false) = EditText(ctx).apply {
        hint = hintText
        setSingleLine(true)
        inputType = if (password)
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        textDirection = View.TEXT_DIRECTION_LTR
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        setTextColor(textMain)
        setHintTextColor(textDim)
        textSize = 14f
        background = round(ctx, card, 14, stroke)
        setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12))
    }

    fun lp(ctx: Context, bottom: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(ctx, bottom) }

    fun label(ctx: Context, t: String, size: Float, color: Int) = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(color)
    }

    fun prefs(ctx: Context) = ctx.getSharedPreferences("xtream", Context.MODE_PRIVATE)

    fun copy(ctx: Context, text: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("links", text))
    }
}
