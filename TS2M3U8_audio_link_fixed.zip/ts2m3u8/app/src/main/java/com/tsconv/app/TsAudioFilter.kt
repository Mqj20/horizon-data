package com.tsconv.app

import java.io.OutputStream

/**
 * يستقبل بث MPEG-TS ويطلّع بث TS جديد فيه الصوت فقط:
 * يقرأ PAT/PMT، يحتفظ بمسارات الصوت، ويعيد بناء الجداول بدون الفيديو.
 */
class TsAudioFilter(private val out: OutputStream) {

    private class Es(val pid: Int, val type: Int, val desc: ByteArray)

    private val carry = ByteArray(188)
    private var carryLen = 0
    private var pmtPid = -1
    private var program = 1
    private val streams = ArrayList<Es>()
    private var ready = false
    private var patCc = 0
    private var pmtCc = 0
    private var count = 0

    fun feed(data: ByteArray, off: Int, len: Int) {
        var i = off
        val end = off + len
        while (i < end) {
            if (carryLen == 0 && data[i] != 0x47.toByte()) { i++; continue }
            val take = minOf(188 - carryLen, end - i)
            System.arraycopy(data, i, carry, carryLen, take)
            carryLen += take
            i += take
            if (carryLen == 188) {
                process(carry)
                carryLen = 0
            }
        }
    }

    private fun u(b: Byte) = b.toInt() and 0xFF

    private fun payloadOffset(p: ByteArray): Int {
        val afc = (u(p[3]) shr 4) and 3
        if (afc and 1 == 0) return -1
        val o = if (afc and 2 != 0) 5 + u(p[4]) else 4
        return if (o < 188) o else -1
    }

    private fun isAudio(type: Int, desc: ByteArray): Boolean {
        if (type == 0x03 || type == 0x04 || type == 0x0F || type == 0x11 || type == 0x81 || type == 0x87) return true
        if (type == 0x06) {
            var i = 0
            while (i + 2 <= desc.size) {
                val tag = u(desc[i])
                if (tag == 0x6A || tag == 0x7A || tag == 0x7B || tag == 0x7C) return true
                i += 2 + u(desc[i + 1])
            }
        }
        return false
    }

    private fun process(p: ByteArray) {
        val pid = ((u(p[1]) and 0x1F) shl 8) or u(p[2])
        if (!ready) {
            if (u(p[1]) and 0x40 == 0) return
            var o = payloadOffset(p)
            if (o < 0) return
            o += 1 + u(p[o])
            if (o + 12 >= 188) return
            if (pid == 0 && pmtPid < 0 && u(p[o]) == 0x00) {
                val sl = ((u(p[o + 1]) and 0x0F) shl 8) or u(p[o + 2])
                var j = o + 8
                val e = minOf(o + 3 + sl - 4, 188)
                while (j + 4 <= e) {
                    val pn = (u(p[j]) shl 8) or u(p[j + 1])
                    val pp = ((u(p[j + 2]) and 0x1F) shl 8) or u(p[j + 3])
                    if (pn != 0) { program = pn; pmtPid = pp; break }
                    j += 4
                }
            } else if (pmtPid >= 0 && pid == pmtPid && u(p[o]) == 0x02) {
                val sl = ((u(p[o + 1]) and 0x0F) shl 8) or u(p[o + 2])
                val pil = ((u(p[o + 10]) and 0x0F) shl 8) or u(p[o + 11])
                var j = o + 12 + pil
                val e = minOf(o + 3 + sl - 4, 188)
                while (j + 5 <= e) {
                    val t = u(p[j])
                    val sp = ((u(p[j + 1]) and 0x1F) shl 8) or u(p[j + 2])
                    val il = ((u(p[j + 3]) and 0x0F) shl 8) or u(p[j + 4])
                    if (j + 5 + il > e) break
                    val d = p.copyOfRange(j + 5, j + 5 + il)
                    if (isAudio(t, d) && streams.size < 8) streams.add(Es(sp, t, d))
                    j += 5 + il
                }
                if (streams.isNotEmpty()) {
                    ready = true
                    writeTables()
                }
            }
            return
        }
        for (s in streams) {
            if (s.pid == pid) {
                out.write(p, 0, 188)
                count++
                if (count % 100 == 0) writeTables()
                return
            }
        }
    }

    private fun writeTables() {
        // PAT
        val pat = ArrayList<Byte>()
        val patBody = byteArrayOf(
            0x00, 0xB0.toByte(), 0x0D, 0x00, 0x01, 0xC1.toByte(), 0x00, 0x00,
            (program shr 8).toByte(), program.toByte(),
            (0xE0 or (pmtPid shr 8)).toByte(), pmtPid.toByte()
        )
        for (b in patBody) pat.add(b)
        addCrc(pat)
        out.write(sectionPacket(0, patCc++, pat.toByteArray()))

        // PMT (بدون فيديو)
        val es = ArrayList<Byte>()
        for (s in streams) {
            es.add(s.type.toByte())
            es.add((0xE0 or (s.pid shr 8)).toByte())
            es.add(s.pid.toByte())
            es.add((0xF0 or (s.desc.size shr 8)).toByte())
            es.add(s.desc.size.toByte())
            for (b in s.desc) es.add(b)
        }
        val pcr = streams[0].pid
        val l = 9 + es.size + 4
        val pmt = ArrayList<Byte>()
        val head = byteArrayOf(
            0x02, (0xB0 or (l shr 8)).toByte(), l.toByte(),
            (program shr 8).toByte(), program.toByte(),
            0xC1.toByte(), 0x00, 0x00,
            (0xE0 or (pcr shr 8)).toByte(), pcr.toByte(),
            0xF0.toByte(), 0x00
        )
        for (b in head) pmt.add(b)
        pmt.addAll(es)
        addCrc(pmt)
        out.write(sectionPacket(pmtPid, pmtCc++, pmt.toByteArray()))
    }

    private fun sectionPacket(pid: Int, cc: Int, section: ByteArray): ByteArray {
        val pkt = ByteArray(188) { 0xFF.toByte() }
        pkt[0] = 0x47
        pkt[1] = (0x40 or (pid shr 8)).toByte()
        pkt[2] = pid.toByte()
        pkt[3] = (0x10 or (cc and 15)).toByte()
        pkt[4] = 0
        val n = minOf(section.size, 183)
        System.arraycopy(section, 0, pkt, 5, n)
        return pkt
    }

    private fun addCrc(list: ArrayList<Byte>) {
        var c = -1
        for (b in list) {
            c = c xor (u(b) shl 24)
            repeat(8) { c = if (c < 0) (c shl 1) xor 0x04C11DB7 else c shl 1 }
        }
        list.add((c ushr 24).toByte()); list.add((c ushr 16).toByte())
        list.add((c ushr 8).toByte()); list.add(c.toByte())
    }
}
