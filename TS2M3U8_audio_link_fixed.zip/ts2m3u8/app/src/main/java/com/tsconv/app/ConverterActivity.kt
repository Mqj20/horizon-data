package com.tsconv.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class ConverterActivity : Activity() {

    // ألوان الواجهة: أسود فحمي + ذهبي
    private val bg = Color.parseColor("#0B0B10")
    private val card = Color.parseColor("#15151D")
    private val stroke = Color.parseColor("#2B2B38")
    private val gold = Color.parseColor("#D4AF37")
    private val textMain = Color.parseColor("#F2EEE3")
    private val textDim = Color.parseColor("#8C8A94")

    private lateinit var input: EditText
    private lateinit var outView: TextView
    private lateinit var info: TextView
    private lateinit var eyeBtn: Button
    private lateinit var tsBtn: Button
    private lateinit var m3uBtn: Button

    private var toM3u8 = true
    private var realOut = ""
    private var revealed = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }

        // ---- الشعار ----
        root.addView(android.widget.ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(dp(120), dp(120)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(8)
        })

        // ---- العنوان ----
        root.addView(TextView(this).apply {
            text = "TS  ⇄  M3U8"
            textSize = 28f
            setTextColor(gold)
            letterSpacing = 0.18f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "محوّل روابط البث"
            textSize = 13f
            setTextColor(textDim)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(20))
        })

        // ---- اختيار الاتجاه ----
        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(card, 30, stroke)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        tsBtn = pill(".ts  ➜  .m3u8") { toM3u8 = true; refreshMode(); convert() }
        m3uBtn = pill(".m3u8  ➜  .ts") { toM3u8 = false; refreshMode(); convert() }
        seg.addView(tsBtn, weight())
        seg.addView(m3uBtn, weight())
        root.addView(seg, matchWrap(bottom = 18))

        // ---- المدخل ----
        root.addView(caption("المدخل"))
        input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_VARIATION_URI
            minLines = 5
            maxLines = 8
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(textMain)
            setHintTextColor(textDim)
            hint = "الصق الرابط أو قائمة M3U هنا"
            textSize = 14f
            background = round(card, 18, stroke)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(input, matchWrap(bottom = 12))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(action("لصق", false) { pasteClip() }, weight(end = 8))
        row1.addView(action("تحويل", true) { convert() }, weight(end = 8))
        row1.addView(action("مسح", false) { clearAll() }, weight())
        root.addView(row1, matchWrap(bottom = 22))

        // ---- النتيجة ----
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(caption("النتيجة").apply { setPadding(0, 0, 0, 0) }, weight())
        eyeBtn = Button(this).apply {
            isAllCaps = false
            textSize = 12f
            setTextColor(gold)
            stateListAnimator = null
            background = null
            setOnClickListener { revealed = !revealed; render() }
        }
        head.addView(eyeBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, dp(36)))
        root.addView(head, matchWrap(bottom = 6))

        outView = TextView(this).apply {
            textSize = 14f
            setTextColor(textMain)
            minLines = 5
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_LTR
            background = round(card, 18, stroke)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(outView, matchWrap(bottom = 8))

        info = TextView(this).apply {
            textSize = 12f
            setTextColor(textDim)
            gravity = Gravity.CENTER
        }
        root.addView(info, matchWrap(bottom = 14))

        root.addView(action("▶   تشغيل البث", true) { playOut() }, matchWrap(bottom = 10))

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(action("نسخ", false) { copyOut() }, weight(end = 8))
        row2.addView(action("مشاركة", false) { shareOut() }, weight())
        root.addView(row2, matchWrap(bottom = 24))

        root.addView(TextView(this).apply {
            text = "صُنع بواسطة  @MQJ_2  ✈"
            textSize = 12f
            setTextColor(gold)
            alpha = 0.85f
            letterSpacing = 0.08f
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_LTR
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
            setPadding(0, dp(8), 0, dp(8))
            setOnClickListener {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/MQJ_2")))
                } catch (e: Exception) {
                    Toast.makeText(this@ConverterActivity, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show()
                }
            }
        }, matchWrap())

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            addView(root)
        })

        refreshMode()
        render()

        if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { input.setText(it); convert() }
        }
    }

    // ---------- عناصر الواجهة ----------
    private fun round(fill: Int, radius: Int, strokeColor: Int? = null) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (strokeColor != null) setStroke(dp(1), strokeColor)
    }

    private fun ripple(content: GradientDrawable) =
        RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), content, null)

    private fun caption(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(textDim)
        letterSpacing = 0.1f
        setPadding(dp(4), 0, 0, dp(6))
    }

    private fun action(t: String, primary: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 15f
        stateListAnimator = null
        setTextColor(if (primary) Color.parseColor("#1A1405") else textMain)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        background = ripple(if (primary) round(gold, 16) else round(card, 16, stroke))
        minHeight = dp(50)
        setOnClickListener { onClick() }
    }

    private fun pill(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 13f
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

    private fun weight(end: Int = 0) =
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = dp(end)
        }

    private fun matchWrap(bottom: Int = 0) =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(bottom) }

    private fun refreshMode() {
        fun style(b: Button, on: Boolean) {
            b.setTextColor(if (on) Color.parseColor("#1A1405") else textDim)
            b.background = if (on) round(gold, 26) else null
        }
        style(tsBtn, toM3u8)
        style(m3uBtn, !toM3u8)
    }

    // ---------- المنطق ----------
    private fun convert() {
        val lines = input.text.toString().split("\n")
        var changed = 0
        realOut = lines.joinToString("\n") { l ->
            val n = convertLine(l, toM3u8)
            if (n != l.trimEnd('\r')) changed++
            n
        }
        info.text = if (realOut.isBlank()) "" else "تم تحويل $changed رابط  •  بيانات الاشتراك مخفية"
        render()
    }

    private fun render() {
        outView.text = when {
            realOut.isEmpty() -> ""
            revealed -> realOut
            else -> realOut.split("\n").joinToString("\n") { maskLine(it) }
        }
        eyeBtn.text = if (revealed) "🙈  إخفاء التفاصيل" else "👁  إظهار التفاصيل"
    }

    private fun clearAll() {
        input.setText("")
        realOut = ""
        revealed = false
        info.text = ""
        render()
    }

    private fun pasteClip() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)
        if (!t.isNullOrEmpty()) { input.setText(t); convert() }
    }

    private fun playOut() {
        if (realOut.isEmpty()) convert()
        // (الاسم، الرابط) — الاسم من سطر #EXTINF إن وُجد
        val items = ArrayList<Pair<String?, String>>()
        var name: String? = null
        for (raw in realOut.split("\n")) {
            val l = raw.trim()
            when {
                l.startsWith("#EXTINF", true) -> name = l.substringAfterLast(',', "").trim().ifEmpty { null }
                l.startsWith("http", true) -> { items.add(name to l); name = null }
            }
        }
        when {
            items.isEmpty() -> Toast.makeText(this, "لا يوجد رابط للتشغيل", Toast.LENGTH_SHORT).show()
            items.size == 1 -> openPlayer(items[0].second)
            else -> {
                val labels = items.mapIndexed { i, (n, u) -> "${i + 1}.  ${n ?: maskLine(u)}" }.toTypedArray()
                android.app.AlertDialog.Builder(this)
                    .setTitle("اختر ما تريد تشغيله")
                    .setItems(labels) { _, which -> openPlayer(items[which].second) }
                    .show()
            }
        }
    }

    private fun openPlayer(url: String) {
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", url))
    }

    private fun copyOut() {
        if (realOut.isEmpty()) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("links", realOut))
        Toast.makeText(this, "تم نسخ الروابط الكاملة", Toast.LENGTH_SHORT).show()
    }

    private fun shareOut() {
        if (realOut.isEmpty()) return
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, realOut)
        }, "مشاركة"))
    }

    companion object {
        private const val DOTS = "••••••"
        private val SECRET_KEYS = setOf("username", "password", "user", "pass", "pwd", "token", "key")

        /** يحوّل سطراً واحداً. الأسطر غير الروابط (مثل #EXTINF) تبقى كما هي. */
        fun convertLine(line: String, toM3u8: Boolean): String {
            val t = line.trim()
            if (t.isEmpty() || t.startsWith("#") || !t.startsWith("http", ignoreCase = true)) return line
            val q = t.indexOfFirst { it == '?' || it == '#' }
            val base = if (q >= 0) t.substring(0, q) else t
            val tail = if (q >= 0) t.substring(q) else ""
            val out = if (toM3u8) {
                when {
                    base.endsWith(".m3u8", true) -> base
                    base.endsWith(".ts", true) -> base.dropLast(3) + ".m3u8"
                    else -> {
                        // رابط Xtream بدون امتداد: .../user/pass/12345
                        val last = base.substringAfterLast('/')
                        if (base.count { it == '/' } >= 4 && last.isNotEmpty() && last.all { it.isDigit() })
                            "$base.m3u8" else base
                    }
                }
            } else {
                if (base.endsWith(".m3u8", true)) base.dropLast(5) + ".ts" else base
            }
            return out + tail
        }

        /** يخفي السيرفر واسم المستخدم وكلمة المرور (Xtream path أو query) للعرض فقط. */
        fun maskLine(line: String): String {
            val t = line.trim()
            if (!t.startsWith("http", ignoreCase = true)) return line
            val schemeEnd = t.indexOf("://")
            if (schemeEnd < 0) return line
            val scheme = t.substring(0, schemeEnd + 3)
            val rest = t.substring(schemeEnd + 3)
            val slash = rest.indexOf('/')
            if (slash < 0) return scheme + DOTS
            var path = rest.substring(slash)
            var query = ""
            val qi = path.indexOf('?')
            if (qi >= 0) { query = path.substring(qi); path = path.substring(0, qi) }

            val segs = path.split("/").toMutableList()          // ["", "live", user, pass, "123.m3u8"]
            val stem = segs.last().substringBeforeLast('.', segs.last())
            if (segs.size >= 4 && stem.isNotEmpty() && stem.all { it.isDigit() }) {
                segs[segs.size - 3] = DOTS
                segs[segs.size - 2] = DOTS
            }
            if (query.isNotEmpty()) {
                query = "?" + query.substring(1).split("&").joinToString("&") { kv ->
                    val k = kv.substringBefore('=')
                    if (kv.contains('=') && k.lowercase() in SECRET_KEYS) "$k=$DOTS" else kv
                }
            }
            return scheme + DOTS + segs.joinToString("/") + query
        }
    }
}
