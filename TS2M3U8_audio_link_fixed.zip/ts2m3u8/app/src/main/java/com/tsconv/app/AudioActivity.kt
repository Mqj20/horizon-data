package com.tsconv.app

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

/** الصق رابط قناة ← يطلع لك رابط صوتي (صوت فقط، بدون صورة). */
class AudioActivity : Activity() {

    private lateinit var input: EditText
    private lateinit var result: LinearLayout
    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.bg
        window.navigationBarColor = Ui.bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.bg)
            setPadding(dp(18), dp(30), dp(18), dp(24))
        }
        root.addView(Ui.label(this, "🎧  رابط صوتي للقناة", 22f, Ui.gold), Ui.lp(this, 6))
        root.addView(
            Ui.label(this, "الصق رابط القناة (m3u8 أو ts) وراح يطلع لك رابط جديد يعرض الصوت فقط بدون صورة.", 13f, Ui.textDim),
            Ui.lp(this, 14)
        )

        input = Ui.field(this, "رابط القناة")
        input.setText(Ui.prefs(this).getString("audio_last", ""))
        root.addView(input, Ui.lp(this, 10))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.button(this, "لصق", false) { paste() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        row.addView(Ui.button(this, "🎧 إنشاء الرابط الصوتي", true) { generate() },
            LinearLayout.LayoutParams(0, -2, 2f))
        root.addView(row, Ui.lp(this, 14))

        result = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(result, Ui.lp(this))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.bg)
            isFillViewport = true
            addView(root)
        })
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (t.isNullOrBlank()) Toast.makeText(this, "الحافظة فاضية", Toast.LENGTH_SHORT).show()
        else input.setText(t.trim())
    }

    private fun generate() {
        val url = input.text.toString().trim().lineSequence().map { it.trim() }
            .firstOrNull { it.startsWith("http", true) }
        if (url == null) {
            Toast.makeText(this, "الصق رابط صحيح يبدأ بـ http", Toast.LENGTH_SHORT).show()
            return
        }
        Ui.prefs(this).edit().putString("audio_last", url).apply()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        thread {
            try {
                AudioServer.start()
                runOnUiThread {
                    AudioService.start(this)
                    showResult(url)
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "تعذر تشغيل السيرفر الصوتي", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun showResult(source: String) {
        result.removeAllViews()
        val local = AudioServer.link("127.0.0.1", source)
        addLink("الرابط الصوتي (على نفس الجهاز)", local)
        AudioServer.lanIp()?.let { addLink("لجهاز ثاني على نفس الواي فاي", AudioServer.link(it, source)) }

        result.addView(Ui.button(this, "▶ فتح بمشغل (VLC مثلاً)", true) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(local), "video/mp2t"))
            } catch (e: Exception) {
                Toast.makeText(this, "ما لقيت مشغل، انسخ الرابط وألصقه بالمشغل", Toast.LENGTH_LONG).show()
            }
        }, Ui.lp(this, 8))
        result.addView(Ui.button(this, "⏹ إيقاف السيرفر الصوتي", false) {
            AudioService.stop(this)
            result.removeAllViews()
        }, Ui.lp(this, 10))
        result.addView(
            Ui.label(this, "الرابط يشتغل طالما التطبيق شغال (الإشعار ظاهر). أي مشغل يفتحه يعرض الصوت فقط.", 12f, Ui.textDim),
            Ui.lp(this)
        )
    }

    private fun addLink(title: String, link: String) {
        result.addView(Ui.label(this, title, 12f, Ui.textDim), Ui.lp(this, 4))
        val tv = TextView(this).apply {
            text = link
            textSize = 13f
            setTextIsSelectable(true)
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.START
            setTextColor(Ui.textMain)
            background = Ui.round(this@AudioActivity, Ui.card, 14, Ui.stroke)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        result.addView(tv, Ui.lp(this, 6))
        result.addView(Ui.button(this, "نسخ الرابط", false) { Ui.copy(this, link) }, Ui.lp(this, 12))
    }
}
