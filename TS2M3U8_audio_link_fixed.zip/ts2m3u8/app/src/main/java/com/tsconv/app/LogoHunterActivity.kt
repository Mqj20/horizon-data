package com.tsconv.app

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** صائد اللوغوات: يجلب اسم القناة + رابط بثها + رابط لوغوها من الاكستريم (stream_icon) أو من قائمة M3U (tvg-logo). */
class LogoHunterActivity : ExportActivity() {

    private lateinit var server: EditText
    private lateinit var user: EditText
    private lateinit var pass: EditText
    private lateinit var filter: EditText
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var info: TextView
    private lateinit var xtBox: LinearLayout
    private lateinit var m3uBox: LinearLayout
    private lateinit var xtBtn: Button
    private lateinit var m3uBtn: Button
    private lateinit var extBtn: Button
    private var xtreamMode = true
    private var ext = "m3u8"
    private var rows: List<Export.Row> = emptyList()

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.bg
        window.navigationBarColor = Ui.bg
        val p = Ui.prefs(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.bg)
            setPadding(dp(18), dp(30), dp(18), dp(24))
        }
        root.addView(Ui.label(this, "🖼  صائد اللوغوات", 22f, Ui.gold), Ui.lp(this, 6))
        root.addView(Ui.label(this, "ينسخ اسم القناة + رابط بثها + رابط لوغوها", 12f, Ui.textDim), Ui.lp(this, 12))

        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.round(this@LogoHunterActivity, Ui.card, 30, Ui.stroke)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        xtBtn = pill("من الاكستريم") { xtreamMode = true; refresh() }
        m3uBtn = pill("من قائمة M3U") { xtreamMode = false; refresh() }
        seg.addView(xtBtn, LinearLayout.LayoutParams(0, -2, 1f))
        seg.addView(m3uBtn, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(seg, Ui.lp(this, 10))

        // ---- الاكستريم ----
        xtBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        server = Ui.field(this, "السيرفر (host:port) أو رابط get.php كامل")
        server.setText(p.getString("lh_server", ""))
        user = Ui.field(this, "اسم المستخدم (اختياري لو بالرابط)")
        user.setText(p.getString("lh_user", ""))
        pass = Ui.field(this, "كلمة المرور (اختياري لو بالرابط)", password = true)
        pass.setText(p.getString("lh_pass", ""))
        filter = Ui.field(this, "فلتر اسم الباقة (اختياري، مثال: sport)")
        filter.setText(p.getString("lh_filter", ""))
        xtBox.addView(server, Ui.lp(this, 6)); xtBox.addView(user, Ui.lp(this, 6))
        xtBox.addView(pass, Ui.lp(this, 6)); xtBox.addView(filter, Ui.lp(this, 8))
        extBtn = Ui.button(this, "", false) { ext = if (ext == "m3u8") "ts" else "m3u8"; refresh() }
        xtBox.addView(extBtn, Ui.lp(this, 8))
        xtBox.addView(Ui.button(this, "جلب القنوات مع لوغوهاتها", true) { fetchXtream() }, Ui.lp(this, 0))
        root.addView(xtBox, Ui.lp(this, 12))

        // ---- M3U ----
        m3uBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        input = EditText(this).apply {
            minLines = 6; maxLines = 10
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(Ui.textMain); setHintTextColor(Ui.textDim)
            hint = "الصق قائمة M3U (اللوغو من tvg-logo)"
            textSize = 14f
            background = Ui.round(this@LogoHunterActivity, Ui.card, 18, Ui.stroke)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        m3uBox.addView(input, Ui.lp(this, 8))
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r.addView(Ui.button(this, "لصق", false) { paste() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        r.addView(Ui.button(this, "استخراج", true) { parseM3u() }, LinearLayout.LayoutParams(0, -2, 1f))
        m3uBox.addView(r, Ui.lp(this, 0))
        root.addView(m3uBox, Ui.lp(this, 12))

        root.addView(Ui.label(this, "النتيجة", 12f, Ui.textDim), Ui.lp(this, 4))
        output = TextView(this).apply {
            textSize = 12f; setTextColor(Ui.textMain)
            minLines = 6
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_LTR
            setTextIsSelectable(true)
            background = Ui.round(this@LogoHunterActivity, Ui.card, 18, Ui.stroke)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(output, Ui.lp(this, 8))
        info = Ui.label(this, "", 12f, Ui.textDim).apply { gravity = Gravity.CENTER }
        root.addView(info, Ui.lp(this, 12))

        root.addView(exportPanel { rows }, Ui.lp(this, 0))

        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.bg); isFillViewport = true; addView(root) })
        refresh()
    }

    private fun pill(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 13f; stateListAnimator = null
        setOnClickListener { onClick() }
    }

    private fun refresh() {
        fun style(b: Button, on: Boolean) {
            b.setTextColor(if (on) android.graphics.Color.parseColor("#1A1405") else Ui.textDim)
            b.background = if (on) Ui.round(this, Ui.gold, 26) else null
        }
        style(xtBtn, xtreamMode); style(m3uBtn, !xtreamMode)
        xtBox.visibility = if (xtreamMode) View.VISIBLE else View.GONE
        m3uBox.visibility = if (xtreamMode) View.GONE else View.VISIBLE
        extBtn.text = "صيغة الرابط: .$ext  (اضغط للتبديل)"
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)
        if (!t.isNullOrEmpty()) input.setText(t)
    }

    private fun show(list: List<Export.Row>, note: String = "") {
        rows = list
        output.text = Export.group(list).let { g -> "${g.size} قناة (الجودات مدموجة)\n\n" + Export.names(g.take(30)) + (if (g.size > 30) "\n\n…" else "") }
        val withLogo = list.count { it.logo.isNotBlank() }
        info.text = "${list.size} قناة، $withLogo منها بلوغو" + note
    }

    // ---------- M3U ----------
    private fun parseM3u() {
        val logoRx = Regex("tvg-logo=\"([^\"]*)\"", RegexOption.IGNORE_CASE)
        val out = ArrayList<Export.Row>()
        var name: String? = null
        var logo = ""
        for (raw in input.text.toString().split("\n")) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#EXTINF", true)) {
                logo = logoRx.find(l)?.groupValues?.get(1)?.trim().orEmpty()
                name = l.substringAfterLast(',', "").trim()
                continue
            }
            if (l.startsWith("#")) continue
            if (l.startsWith("http", true)) {
                out.add(Export.Row(name?.ifBlank { null } ?: "قناة ${out.size + 1}", l, logo))
                name = null; logo = ""
            }
        }
        if (out.isEmpty()) { toast("ما لقيت قنوات بالقائمة"); return }
        show(out)
    }

    // ---------- الاكستريم ----------
    private fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15_000; c.readTimeout = 60_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "VLC/3.0.20 LibVLC/3.0.20")
            val code = c.responseCode
            if (code !in 200..299) throw Exception("رمز السيرفر: $code")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun fetchXtream() {
        var cr = XtreamApi.parseServer(server.text.toString())
        if (cr == null) { toast("اكتب عنوان السيرفر"); return }
        val u = user.text.toString().trim().ifEmpty { cr.user }
        val pw = pass.text.toString().trim().ifEmpty { cr.pass }
        if (u.isEmpty() || pw.isEmpty()) { toast("ناقص اسم المستخدم أو كلمة المرور"); return }
        cr = XtreamApi.Creds(cr.base, u, pw)
        Ui.prefs(this).edit().putString("lh_server", server.text.toString()).putString("lh_user", u)
            .putString("lh_pass", pw).putString("lh_filter", filter.text.toString()).apply()
        val creds = cr
        val f = filter.text.toString().trim()
        val extNow = ext
        info.text = "جارٍ الجلب..."
        Thread {
            try {
                XtreamApi.login(creds)
                var cats = XtreamApi.categories(creds)
                if (f.isNotEmpty()) cats = cats.filter { it.name.contains(f, true) }
                if (cats.isEmpty()) throw Exception("ما لقيت باقات بهذا الفلتر")
                val out = ArrayList<Export.Row>()
                var capped = false
                for ((i, cat) in cats.withIndex()) {
                    runOnUiThread { info.text = "جارٍ الجلب... باقة ${i + 1}/${cats.size}" }
                    val txt = http("${creds.base}/player_api.php?username=${URLEncoder.encode(creds.user, "UTF-8")}" +
                        "&password=${URLEncoder.encode(creds.pass, "UTF-8")}&action=get_live_streams" +
                        "&category_id=${URLEncoder.encode(cat.id, "UTF-8")}").trim()
                    if (!txt.startsWith("[")) continue
                    val arr = JSONArray(txt)
                    for (k in 0 until arr.length()) {
                        val o = arr.optJSONObject(k) ?: continue
                        val id = o.optString("stream_id")
                        out.add(Export.Row(o.optString("name"), "${creds.base}/live/${creds.user}/${creds.pass}/$id.$extNow",
                            o.optString("stream_icon").trim()))
                        if (out.size >= 5000) { capped = true; break }
                    }
                    if (capped) break
                }
                runOnUiThread { show(out, if (capped) " (وقف عند 5000، استخدم الفلتر)" else "") }
            } catch (e: Exception) {
                runOnUiThread { info.text = "فشل: ${e.message}" }
            }
        }.start()
    }
}
