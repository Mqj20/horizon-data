package com.tsconv.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** الشاشة الرئيسية: مربعات، كل مربع يفتح ميزة. الاكستريم أول مربع. */
class MainActivity : Activity() {

    private class Tile(val icon: String, val title: String, val sub: String, val primary: Boolean, val target: Class<*>)

    private val tiles = listOf(
        Tile("📡", "الاكستريم", "حساباتك المحفوظة وباقاتها", true, AccountsActivity::class.java),
        Tile("🖼", "صائد اللوغوات", "اسم + رابط + لوغو", false, LogoHunterActivity::class.java),
        Tile("🔒", "تشفير Horizon", "روابط GT / TV", false, HorizonCryptoActivity::class.java),
        Tile("🔐", "تشفير الروابط", "تشفير وفك", false, CryptoActivity::class.java),
        Tile("📂", "فحص ملف القنوات", "شفّر الروابط داخل content_v2.json", true, HorizonCryptoActivity::class.java),
        Tile("📁", "تشفير ملف", "ارفع ملف وشفّره كامل", false, FileCryptoActivity::class.java),
        Tile("🔁", "محوّل TS ⇄ M3U8", "رابط أو قائمة", false, ConverterActivity::class.java),
        Tile("🎧", "رابط صوتي للقناة", "رابط صوتي فقط (بدون صورة)", false, AudioActivity::class.java)
    )

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.bg
        window.navigationBarColor = Ui.bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.bg)
            setPadding(dp(18), dp(32), dp(18), dp(24))
        }

        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(dp(96), dp(96)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(6)
        })
        root.addView(TextView(this).apply {
            text = "MQJ  M3U8"
            textSize = 24f
            setTextColor(Ui.gold)
            letterSpacing = 0.18f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(18))
        })

        // مربعات بعمودين، كل مربع عرضه = ارتفاعه
        val gap = dp(12)
        val side = (resources.displayMetrics.widthPixels - dp(36) - gap) / 2
        tiles.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, t ->
                row.addView(tileView(t), LinearLayout.LayoutParams(side, side).apply {
                    if (i == 0) marginEnd = gap
                })
            }
            root.addView(row, Ui.lp(this, 12))
        }

        root.addView(TextView(this).apply {
            text = "صُنع بواسطة  @MQJ_2  ✈"
            textSize = 12f
            setTextColor(Ui.gold)
            alpha = 0.85f
            letterSpacing = 0.08f
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_LTR
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
            setPadding(0, dp(14), 0, dp(8))
            setOnClickListener {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/MQJ_2")))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show()
                }
            }
        }, Ui.lp(this))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.bg)
            isFillViewport = true
            addView(root)
        })
    }

    private fun tileView(t: Tile) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = Ui.ripple(
            if (t.primary) Ui.round(this@MainActivity, Ui.gold, 20)
            else Ui.round(this@MainActivity, Ui.card, 20, Ui.stroke)
        )
        setPadding(dp(8), dp(8), dp(8), dp(8))
        val main = if (t.primary) Color.parseColor("#1A1405") else Ui.textMain
        val dim = if (t.primary) Color.parseColor("#4A3D12") else Ui.textDim
        addView(TextView(context).apply { text = t.icon; textSize = 38f; gravity = Gravity.CENTER })
        addView(TextView(context).apply {
            text = t.title; textSize = 15f; setTextColor(main); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(0, dp(8), 0, dp(2))
        })
        addView(TextView(context).apply { text = t.sub; textSize = 11f; setTextColor(dim); gravity = Gravity.CENTER })
        setOnClickListener {
            startActivity(Intent(this@MainActivity, t.target).apply { if (t.title == "فحص ملف القنوات") putExtra("pick", true) })
        }
    }
}
