package com.tsconv.app

import android.app.Activity
import android.content.Intent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

/** أساس مشترك: لوحة أزرار النسخ المنفصل (اسم / رابط / لوغو) + النسخ المشفر + حفظ ملف JSON. */
abstract class ExportActivity : Activity() {

    private var pendingText: String? = null
    private var gcm = true
    private lateinit var encBtn: Button

    protected fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun copyBig(text: String, ok: String) {
        try { Ui.copy(this, text); toast(ok) } catch (e: Exception) { toast("الحجم كبير على النسخ، استخدم حفظ الملف") }
    }

    protected fun saveFile(fileName: String, text: String) {
        pendingText = text
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, fileName)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_SAVE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SAVE) return
        val uri = data?.data
        val text = pendingText
        pendingText = null
        if (resultCode != RESULT_OK || uri == null || text == null) return
        try {
            contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            toast("تم حفظ الملف")
        } catch (e: Exception) { toast("فشل حفظ الملف") }
    }

    /** rows: القنوات الحالية (اسم، رابط بث، لوغو). تُقرأ لحظة الضغط. */
    protected fun exportPanel(rows: () -> List<Export.Row>): LinearLayout {
        fun groups(): List<Export.Group>? {
            val r = rows()
            if (r.isEmpty()) { toast("ما في قنوات"); return null }
            return Export.group(r)
        }
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        p.addView(Ui.label(this, "نسخ منفصل (فاصل بين كل قناة)", 12f, Ui.textDim), Ui.lp(this, 6))

        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun small(t: String, last: Boolean, f: () -> Unit) = r1.addView(Ui.button(this, t, false, f),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { if (!last) marginEnd = Ui.dp(this@ExportActivity, 8) })
        small("📝 الأسماء", false) { groups()?.let { copyBig(Export.names(it), "تم نسخ ${it.size} اسم") } }
        small("🔗 الروابط", false) { groups()?.let { copyBig(Export.urls(it), "تم نسخ روابط ${it.size} قناة") } }
        small("🖼 اللوغوات", true) { groups()?.let { copyBig(Export.logos(it), "تم نسخ اللوغوات") } }
        p.addView(r1, Ui.lp(this, 14))

        p.addView(Ui.label(this, "مشفّر: الاسم واللوغو عاديان، الرابط فقط مشفر", 12f, Ui.textDim), Ui.lp(this, 6))
        encBtn = Ui.button(this, "", false) { gcm = !gcm; refreshEnc() }
        p.addView(encBtn, Ui.lp(this, 8))
        p.addView(Ui.button(this, "🔒 نسخ: اسم + رابط مشفر + لوغو", false) {
            groups()?.let { copyBig(Export.encBlocks(it, Export.encoder(gcm)), "تم نسخ ${it.size} قناة مشفرة") }
        }, Ui.lp(this, 8))
        p.addView(Ui.button(this, "📄 حفظ ملف content_v2.json", true) {
            groups()?.let { saveFile("content_v2.json", Export.json(it, Export.encoder(gcm))) }
        }, Ui.lp(this, 0))
        refreshEnc()
        return p
    }

    private fun refreshEnc() {
        encBtn.text = "التشفير: " + (if (gcm) "AES-256-GCM (الجديد)" else "AES-CBC (القديم)") + "  (اضغط للتبديل)"
    }

    companion object { private const val REQ_SAVE = 91 }
}
